Src/clock.o: ../Src/clock.c ../Inc/registers.h ../Inc/clock.h
../Inc/registers.h:
../Inc/clock.h:
