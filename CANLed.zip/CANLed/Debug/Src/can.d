Src/can.o: ../Src/can.c ../Inc/registers.h ../Inc/can.h
../Inc/registers.h:
../Inc/can.h:
