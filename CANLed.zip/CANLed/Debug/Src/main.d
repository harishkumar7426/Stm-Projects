Src/main.o: ../Src/main.c ../Inc/registers.h ../Inc/uart.h ../Inc/can.h
../Inc/registers.h:
../Inc/uart.h:
../Inc/can.h:
