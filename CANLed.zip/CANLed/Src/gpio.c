#include "registers.h"
#include "gpio.h"

void LED_Init(void)
{
    RCC_AHB1ENR |= (1<<0);

    GPIOA_MODER &= ~(3<<(5*2));
    GPIOA_MODER |=  (1<<(5*2));
}

void LED_ON(void)
{
    GPIOA_ODR |= (1<<5);
}

void LED_OFF(void)
{
    GPIOA_ODR &= ~(1<<5);
}

void Button_Init(void)
{
    RCC_AHB1ENR |= (1<<2);

    GPIOC_MODER &= ~(3<<(13*2));

    GPIOC_PUPDR &= ~(3<<(13*2));
    GPIOC_PUPDR |=  (1<<(13*2));
}

unsigned char Button_Read(void)
{
    return !(GPIOC_IDR & (1<<13));
}
