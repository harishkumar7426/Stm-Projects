#include "registers.h"
#include "can.h"

void CAN1_Init(void)
{
    /* 1. Enable clocks for GPIOB and CAN1 */
    RCC_AHB1ENR |= (1U << 1);      // GPIOB clock
    RCC_APB1ENR |= (1U << 25);     // CAN1 clock

    /* 2. Configure PB8 (RX) and PB9 (TX) as Alternate Function */
    GPIOB_MODER &= ~((3U << (8 * 2)) | (3U << (9 * 2)));
    GPIOB_MODER |=  ((2U << (8 * 2)) | (2U << (9 * 2)));

    /* Select AF9 (CAN1) for PB8 and PB9 */
    GPIOB_AFRH &= ~((0xFU << 0) | (0xFU << 4));
    GPIOB_AFRH |=  ((9U << 0)   | (9U << 4));

    /* 3. Request CAN Initialization Mode */
    CAN_MCR |= (1U << 0);          // INRQ = 1
    while ((CAN_MSR & (1U << 0)) == 0); // Wait until INAK = 1

    /* Disable Auto-Retransmission (NART = 1) & Exit Sleep Mode */
    CAN_MCR |= (1U << 4);          // NART
    CAN_MCR &= ~(1U << 1);         // SLEEP = 0

    /* 4. Bit Timing Register (BTR) Configuration
       Target: 125 kbps @ 16 MHz APB1 Clock
       BRP = 7 (+1 = 8), TS1 = 12 (+1 = 13 Quanta), TS2 = 1 (+1 = 2 Quanta)
       Total Quanta = 1 + 13 + 2 = 16 Quanta -> 16 MHz / (8 * 16) = 125 kbps
       Modes: Loopback (LBKM) + Silent (SILM) */
    CAN_BTR = (0U << 24) | (12U << 16) | (1U << 20) | (7U << 0);         /* BRP = 8 */

    /* 5. Filter Configuration (Accept All to FIFO0) */
    CAN_FMR |= (1U << 0);          // FINIT = 1 (Filter init mode)

    CAN_FA1R &= ~(1U << 0);        // Deactivate Filter 0
    CAN_FM1R &= ~(1U << 0);        // Identifier Mask mode
    CAN_FS1R |=  (1U << 0);        // Single 32-bit scale configuration
    CAN_FFA1R &= ~(1U << 0);       // Assign Filter 0 to FIFO 0

    CAN_F0R1 = 0x00000000;         // ID = 0
    CAN_F0R2 = 0x00000000;         // Mask = 0 (Match everything)

    CAN_FA1R |= (1U << 0);         // Activate Filter 0
    CAN_FMR &= ~(1U << 0);         // Exit Filter init mode

    /* 6. Leave CAN Initialization Mode */
    CAN_MCR &= ~(1U << 0);         // INRQ = 0
    while (CAN_MSR & (1U << 0));   // Wait until INAK = 0
}

void CAN1_Send(uint32_t data)
{
    /* Wait until Mailbox 0 is empty */
    while ((CAN_TSR & (1U << 26)) == 0);

    /* Standard ID = 0x123 */
    CAN_TI0R  = (0x123U << 21);

    /* DLC = 4 bytes (32-bit) */
    CAN_TDT0R = 4U;

    /* Load 32-bit data */
    CAN_TDL0R = data;

    /* Request transmission */
    CAN_TI0R |= (1U << 0);
}

uint8_t CAN1_Receive(uint32_t *data)
{
    /* Any message pending in FIFO0? */
    if ((CAN_RF0R & 0x03U) == 0)
    {
        return 0;
    }

    /* Read full 32-bit data */
    *data = CAN_RDL0R;

    /* Release FIFO0 */
    CAN_RF0R |= (1U << 5);

    return 1;
}
