#include "registers.h"
#include "uart.h"

void UART2_Init(void)
{
    /* GPIOA + USART2 clocks */
    RCC_AHB1ENR |= (1<<0);
    RCC_APB1ENR |= (1<<17);

    /* PA2 = AF */
    GPIOA_MODER &= ~(3<<(2*2));
    GPIOA_MODER |=  (2<<(2*2));

    /* AF7 */
    GPIOA_AFRL &= ~(0xF<<(2*4));
    GPIOA_AFRL |=  (7<<(2*4));

    /* 16 MHz / 115200 = 0x008B */
    USART2_BRR = 0x008B;

    USART2_CR1 |= (1<<3);   // TE
    USART2_CR1 |= (1<<13);  // UE
}

void UART2_SendChar(char c)
{
    while(!(USART2_SR & (1<<7)));
    USART2_DR = c;
}

void UART2_SendString(char *s)
{
    while(*s)
    {
        UART2_SendChar(*s++);
    }
}
