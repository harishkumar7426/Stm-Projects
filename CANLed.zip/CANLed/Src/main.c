/*
 Transmitter:
 #include "registers.h"
#include "uart.h"
#include "can.h"
#include "gpio.h"

void delay(void)
{
    for(volatile uint32_t i=0;i<50000;i++);
}

int main(void)
{
    uint8_t lastState = 0xFF;

    //================= 16 MHz HSI =================
    RCC_CR |= (1U<<0);
    while(!(RCC_CR & (1U<<1)));

    RCC_CFGR &= ~(3U<<0);

    UART2_Init();
    CAN1_Init();
    Button_Init();

    UART2_SendString("TX BOARD READY\\r\\n");

    while(1)
    {
        uint8_t currentState = Button_Read();

        // Send only when state changes
        if(currentState != lastState)
        {
            if(currentState)   // Button pressed
            {
                CAN1_Send(0x00000001U);
                UART2_SendString("BUTTON PRESSED -> CAN = 1\\r\\n");
            }
            else               // Button released
            {
                CAN1_Send(0x00000000U);
                UART2_SendString("BUTTON RELEASED -> CAN = 0\\r\\n");
            }

            lastState = currentState;
        }

        delay();
    }
}
 */
/*Receiver*/
#include "registers.h"
#include "uart.h"
#include "can.h"

uint32_t rx;

int main(void)
{
    /* ================= 16 MHz HSI ================= */
    RCC_CR |= (1U<<0);
    while(!(RCC_CR & (1U<<1)));

    RCC_CFGR &= ~(3U<<0);

    /* ================= LED PA5 ================= */
    RCC_AHB1ENR |= (1U<<0);

    GPIOA_MODER &= ~(3U<<(5*2));
    GPIOA_MODER |=  (1U<<(5*2));

    UART2_Init();
    CAN1_Init();

    UART2_SendString("RX BOARD READY\\r\\n");

    while(1)
    {
        if(CAN1_Receive(&rx))
        {
            if(rx == 0x00000001U)
            {
                /* LED ON */
                GPIOA_ODR |= (1U<<5);
                UART2_SendString("LED ON\\r\\n");
            }
            else if(rx == 0x00000000U)
            {
                /* LED OFF */
                GPIOA_ODR &= ~(1U<<5);
                UART2_SendString("LED OFF\\r\\n");
            }
        }
    }
}
