#include "registers.h"
#include "clock.h"

/* Use HSI directly = 16 MHz */
void Clock_16MHz_Init(void)
{
    /* Enable HSI */
    RCC_CR |= (1<<0);

    /* Wait HSI ready */
    while(!(RCC_CR & (1<<1)));

    /* Select HSI as system clock */
    RCC_CFGR &= ~(3<<0);

    /* Wait until HSI is used */
    while(((RCC_CFGR >> 2) & 0x3) != 0);
}
