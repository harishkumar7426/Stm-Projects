#ifndef CLOCK_H
#define CLOCK_H

void Clock_16MHz_Init(void);

#endif
