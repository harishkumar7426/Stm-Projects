#ifndef CAN_H
#define CAN_H

#include <stdint.h>

void CAN1_Init(void);
void CAN1_Send(uint32_t data);
uint8_t CAN1_Receive(uint32_t *data);

#endif
