#ifndef REGISTERS_H
#define REGISTERS_H

#include <stdint.h>

/* ================= RCC ================= */
#define RCC_BASE        0x40023800UL
#define RCC_CR          (*(volatile uint32_t *)(RCC_BASE + 0x00))
#define RCC_CFGR        (*(volatile uint32_t *)(RCC_BASE + 0x08))
#define RCC_AHB1ENR     (*(volatile uint32_t *)(RCC_BASE + 0x30))
#define RCC_APB1ENR     (*(volatile uint32_t *)(RCC_BASE + 0x40))

/* ================= GPIOA ================= */
#define GPIOA_BASE      0x40020000UL
#define GPIOA_MODER     (*(volatile uint32_t *)(GPIOA_BASE + 0x00))
#define GPIOA_ODR       (*(volatile uint32_t *)(GPIOA_BASE + 0x14))

/* ================= GPIOB ================= */
#define GPIOB_BASE      0x40020400UL
#define GPIOB_MODER     (*(volatile uint32_t *)(GPIOB_BASE + 0x00))
#define GPIOB_AFRH      (*(volatile uint32_t *)(GPIOB_BASE + 0x24))

/* ================= GPIOC ================= */
#define GPIOC_BASE      0x40020800UL
#define GPIOC_MODER     (*(volatile uint32_t *)(GPIOC_BASE + 0x00))
#define GPIOC_PUPDR     (*(volatile uint32_t *)(GPIOC_BASE + 0x0C))
#define GPIOC_IDR       (*(volatile uint32_t *)(GPIOC_BASE + 0x10))

/* ================= CAN1 ================= */
#define CAN1_BASE       0x40006400UL

/* ================= USART2 ================= */
#define USART2_BASE     0x40004400UL

#define USART2_SR       (*(volatile uint32_t *)(USART2_BASE + 0x00))
#define USART2_DR       (*(volatile uint32_t *)(USART2_BASE + 0x04))
#define USART2_BRR      (*(volatile uint32_t *)(USART2_BASE + 0x08))
#define USART2_CR1      (*(volatile uint32_t *)(USART2_BASE + 0x0C))
#define USART2_CR2      (*(volatile uint32_t *)(USART2_BASE + 0x10))

/* GPIOA AFRL */
#define GPIOA_AFRL      (*(volatile uint32_t *)(GPIOA_BASE + 0x20))
#define CAN_MCR         (*(volatile uint32_t *)(CAN1_BASE + 0x000))
#define CAN_MSR         (*(volatile uint32_t *)(CAN1_BASE + 0x004))
#define CAN_TSR         (*(volatile uint32_t *)(CAN1_BASE + 0x008))
#define CAN_RF0R        (*(volatile uint32_t *)(CAN1_BASE + 0x00C))
#define CAN_BTR         (*(volatile uint32_t *)(CAN1_BASE + 0x01C))

#define CAN_TI0R        (*(volatile uint32_t *)(CAN1_BASE + 0x180))
#define CAN_TDT0R       (*(volatile uint32_t *)(CAN1_BASE + 0x184))
#define CAN_TDL0R       (*(volatile uint32_t *)(CAN1_BASE + 0x188))
#define CAN_RDL0R       (*(volatile uint32_t *)(CAN1_BASE + 0x1B8))

#define CAN_FMR         (*(volatile uint32_t *)(CAN1_BASE + 0x200))
#define CAN_FM1R        (*(volatile uint32_t *)(CAN1_BASE + 0x204))
#define CAN_FS1R        (*(volatile uint32_t *)(CAN1_BASE + 0x20C))
#define CAN_FFA1R       (*(volatile uint32_t *)(CAN1_BASE + 0x214))
#define CAN_FA1R        (*(volatile uint32_t *)(CAN1_BASE + 0x21C))
#define CAN_F0R1        (*(volatile uint32_t *)(CAN1_BASE + 0x240))
#define CAN_F0R2        (*(volatile uint32_t *)(CAN1_BASE + 0x244))

#endif
