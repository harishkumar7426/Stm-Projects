#include "registers.h"
#include "gpio.h"

void GPIO_Init(void)
{
    /* Enable GPIOA Clock */

    RCC_AHB1ENR |= (1<<0);

    /* PA1 Output Initially */

    GPIOA_MODER &= ~(3<<(1*2));

    GPIOA_MODER |= (1<<(1*2));

    /* Push Pull */

    GPIOA_OTYPER &= ~(1<<1);

    /* High Speed */

    GPIOA_OSPEEDR |= (3<<(1*2));

    /* No Pull */

    GPIOA_PUPDR &= ~(3<<(1*2));

    /* USART2 Pins */

    GPIOA_MODER &= ~(3<<(2*2));
    GPIOA_MODER |= (2<<(2*2));

    GPIOA_MODER &= ~(3<<(3*2));
    GPIOA_MODER |= (2<<(3*2));

    GPIOA_AFRL |= (7<<(2*4));
    GPIOA_AFRL |= (7<<(3*4));
}

void DHT_Output(void)
{
    GPIOA_MODER &= ~(3<<(1*2));

    GPIOA_MODER |= (1<<(1*2));
}

void DHT_Input(void)
{
    GPIOA_MODER &= ~(3<<(1*2));
}

void DHT_High(void)
{
    GPIOA_BSRR = (1<<1);
}

void DHT_Low(void)
{
    GPIOA_BSRR = (1<<(1+16));
}

unsigned char DHT_ReadPin(void)
{
    if(GPIOA_IDR & (1<<1))

        return 1;

    else

        return 0;
}
