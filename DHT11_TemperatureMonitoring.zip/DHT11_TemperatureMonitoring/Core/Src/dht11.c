/*
 * dht11.c
 *
 *  Created on: Jul 16, 2026
 *      Author: hkuma
 */


#include "dht11.h"
#include "gpio.h"
#include "delay.h"

unsigned char Rh_byte1;
unsigned char Rh_byte2;
unsigned char Temp_byte1;
unsigned char Temp_byte2;
unsigned char Checksum;

unsigned char DHT11_Start(void)
{
    DHT_Output();

    DHT_Low();

    Delay_ms(18);

    DHT_High();

    Delay_us(30);

    DHT_Input();

    Delay_us(40);

    if(DHT_ReadPin())
        return 0;

    while(!DHT_ReadPin());

    while(DHT_ReadPin());

    return 1;
}

unsigned char DHT11_ReadByte(void)
{
    unsigned char i;
    unsigned char data = 0;

    for(i=0;i<8;i++)
    {
        while(!DHT_ReadPin());

        Delay_us(40);

        if(DHT_ReadPin())
        {
            data |= (1<<(7-i));

            while(DHT_ReadPin());
        }
    }

    return data;
}

unsigned char DHT11_ReadData(void)
{
    if(!DHT11_Start())
        return 0;

    Rh_byte1 = DHT11_ReadByte();

    Rh_byte2 = DHT11_ReadByte();

    Temp_byte1 = DHT11_ReadByte();

    Temp_byte2 = DHT11_ReadByte();

    Checksum = DHT11_ReadByte();

    if((Rh_byte1 + Rh_byte2 + Temp_byte1 + Temp_byte2)==Checksum)
        return 1;

    return 0;
}
