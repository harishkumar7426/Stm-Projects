#include "gpio.h"
#include "timer.h"
#include "delay.h"
#include "uart.h"
#include "dht11.h"

int main(void)
{
    GPIO_Init();

    TIM2_Init();

    UART2_Init();

    while(1)
    {
        if(DHT11_ReadData())
        {
            UART2_SendString("Temperature : ");

            UART2_SendNumber(Temp_byte1);

            UART2_SendString(" C\r\n");

            UART2_SendString("Humidity : ");

            UART2_SendNumber(Rh_byte1);

            UART2_SendString(" %\r\n\r\n");
        }
        else
        {
            UART2_SendString("DHT11 Error\r\n\r\n");
        }

        Delay_ms(500);
    }
}
