#include "registers.h"
#include "uart.h"

void UART2_Init(void)
{
    /* Enable USART2 Clock */

    RCC_APB1ENR |= (1<<17);

    /* Configure Baud Rate */

    /* 16MHz ->115200 */

    USART2_BRR = 0x008B;

    /* Enable Transmitter */

    USART2_CR1 |= (1<<3);

    /* Enable Receiver */

    USART2_CR1 |= (1<<2);

    /* Enable USART */

    USART2_CR1 |= (1<<13);
}

void UART2_SendChar(char ch)
{
    /* Wait until TX Register Empty */

    while(!(USART2_SR & (1<<7)));

    USART2_DR = ch;
}

void UART2_SendString(char *str)
{
    while(*str)
    {
        UART2_SendChar(*str++);
    }
}

void UART2_SendNumber(unsigned int num)
{
    char data[10];
    int i = 0;

    if(num == 0)
    {
        UART2_SendChar('0');
        return;
    }

    while(num > 0)
    {
        data[i++] = (num % 10) + '0';
        num = num / 10;
    }

    while(i > 0)
    {
        UART2_SendChar(data[--i]);
    }
}
