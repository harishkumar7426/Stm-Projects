#ifndef GPIO_H
#define GPIO_H

void GPIO_Init(void);

void DHT_Output(void);

void DHT_Input(void);

void DHT_High(void);

void DHT_Low(void);

unsigned char DHT_ReadPin(void);

#endif
