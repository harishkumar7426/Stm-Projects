#ifndef TIMER_H
#define TIMER_H

#include "registers.h"

void TIM2_Init(void);

void Timer_Reset(void);

uint32_t Timer_GetCount(void);

#endif
