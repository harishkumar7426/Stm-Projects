#ifndef DHT11_H
#define DHT11_H

extern unsigned char Rh_byte1;
extern unsigned char Rh_byte2;
extern unsigned char Temp_byte1;
extern unsigned char Temp_byte2;
extern unsigned char Checksum;

unsigned char DHT11_Start(void);

unsigned char DHT11_ReadByte(void);

unsigned char DHT11_ReadData(void);

#endif
