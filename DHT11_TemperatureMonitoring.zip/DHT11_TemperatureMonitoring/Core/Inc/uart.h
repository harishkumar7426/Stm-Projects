#ifndef UART_H
#define UART_H

void UART2_Init(void);

void UART2_SendChar(char ch);

void UART2_SendString(char *str);

void UART2_SendNumber(unsigned int num);

#endif
