Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/gpio.h \
 ../Core/Inc/timer.h ../Core/Inc/registers.h ../Core/Inc/delay.h \
 ../Core/Inc/uart.h ../Core/Inc/dht11.h
../Core/Inc/gpio.h:
../Core/Inc/timer.h:
../Core/Inc/registers.h:
../Core/Inc/delay.h:
../Core/Inc/uart.h:
../Core/Inc/dht11.h:
