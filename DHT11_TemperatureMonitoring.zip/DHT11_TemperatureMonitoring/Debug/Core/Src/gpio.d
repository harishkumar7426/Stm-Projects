Core/Src/gpio.o: ../Core/Src/gpio.c ../Core/Inc/registers.h \
 ../Core/Inc/gpio.h
../Core/Inc/registers.h:
../Core/Inc/gpio.h:
