Core/Src/dht11.o: ../Core/Src/dht11.c ../Core/Inc/dht11.h \
 ../Core/Inc/gpio.h ../Core/Inc/delay.h
../Core/Inc/dht11.h:
../Core/Inc/gpio.h:
../Core/Inc/delay.h:
