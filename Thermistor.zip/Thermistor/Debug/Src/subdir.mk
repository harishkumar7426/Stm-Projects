################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/adc.c \
../Src/current_sensor.c \
../Src/gpio.c \
../Src/inverter_app.c \
../Src/main.c \
../Src/nb_delay.c \
../Src/soft_start_pwm.c \
../Src/startup_stm32f446xx.c \
../Src/syscalls.c \
../Src/sysmem.c \
../Src/temperature_sensor.c \
../Src/uart.c \
../Src/voltage_sensor.c 

OBJS += \
./Src/adc.o \
./Src/current_sensor.o \
./Src/gpio.o \
./Src/inverter_app.o \
./Src/main.o \
./Src/nb_delay.o \
./Src/soft_start_pwm.o \
./Src/startup_stm32f446xx.o \
./Src/syscalls.o \
./Src/sysmem.o \
./Src/temperature_sensor.o \
./Src/uart.o \
./Src/voltage_sensor.o 

C_DEPS += \
./Src/adc.d \
./Src/current_sensor.d \
./Src/gpio.d \
./Src/inverter_app.d \
./Src/main.d \
./Src/nb_delay.d \
./Src/soft_start_pwm.d \
./Src/startup_stm32f446xx.d \
./Src/syscalls.d \
./Src/sysmem.d \
./Src/temperature_sensor.d \
./Src/uart.d \
./Src/voltage_sensor.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F4 -DSTM32F446RETx -DNUCLEO_F446RE -c -I../Inc -O0 -ffunction-sections -fdata-sections -Wall -mfpu=fpv4-sp-d16 -mfloat-abi=hard -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/adc.cyclo ./Src/adc.d ./Src/adc.o ./Src/adc.su ./Src/current_sensor.cyclo ./Src/current_sensor.d ./Src/current_sensor.o ./Src/current_sensor.su ./Src/gpio.cyclo ./Src/gpio.d ./Src/gpio.o ./Src/gpio.su ./Src/inverter_app.cyclo ./Src/inverter_app.d ./Src/inverter_app.o ./Src/inverter_app.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/nb_delay.cyclo ./Src/nb_delay.d ./Src/nb_delay.o ./Src/nb_delay.su ./Src/soft_start_pwm.cyclo ./Src/soft_start_pwm.d ./Src/soft_start_pwm.o ./Src/soft_start_pwm.su ./Src/startup_stm32f446xx.cyclo ./Src/startup_stm32f446xx.d ./Src/startup_stm32f446xx.o ./Src/startup_stm32f446xx.su ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su ./Src/temperature_sensor.cyclo ./Src/temperature_sensor.d ./Src/temperature_sensor.o ./Src/temperature_sensor.su ./Src/uart.cyclo ./Src/uart.d ./Src/uart.o ./Src/uart.su ./Src/voltage_sensor.cyclo ./Src/voltage_sensor.d ./Src/voltage_sensor.o ./Src/voltage_sensor.su

.PHONY: clean-Src

