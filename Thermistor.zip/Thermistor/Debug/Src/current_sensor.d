Src/current_sensor.o: ../Src/current_sensor.c ../Inc/current_sensor.h \
 ../Inc/adc.h ../Inc/stm32f446xx_registers.h
../Inc/current_sensor.h:
../Inc/adc.h:
../Inc/stm32f446xx_registers.h:
