Src/temperature_sensor.o: ../Src/temperature_sensor.c \
 ../Inc/temperature_sensor.h ../Inc/adc.h ../Inc/stm32f446xx_registers.h
../Inc/temperature_sensor.h:
../Inc/adc.h:
../Inc/stm32f446xx_registers.h:
