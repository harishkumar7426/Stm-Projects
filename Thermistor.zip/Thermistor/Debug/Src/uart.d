Src/uart.o: ../Src/uart.c ../Inc/uart.h ../Inc/stm32f446xx_registers.h
../Inc/uart.h:
../Inc/stm32f446xx_registers.h:
