Src/voltage_sensor.o: ../Src/voltage_sensor.c ../Inc/voltage_sensor.h \
 ../Inc/adc.h ../Inc/stm32f446xx_registers.h
../Inc/voltage_sensor.h:
../Inc/adc.h:
../Inc/stm32f446xx_registers.h:
