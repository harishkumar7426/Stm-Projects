Src/gpio.o: ../Src/gpio.c ../Inc/gpio.h ../Inc/stm32f446xx_registers.h
../Inc/gpio.h:
../Inc/stm32f446xx_registers.h:
