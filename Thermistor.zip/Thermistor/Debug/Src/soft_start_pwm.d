Src/soft_start_pwm.o: ../Src/soft_start_pwm.c ../Inc/soft_start_pwm.h \
 ../Inc/stm32f446xx_registers.h
../Inc/soft_start_pwm.h:
../Inc/stm32f446xx_registers.h:
