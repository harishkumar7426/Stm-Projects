Src/adc.o: ../Src/adc.c ../Inc/adc.h ../Inc/stm32f446xx_registers.h \
 ../Inc/stm32f446xx_registers.h
../Inc/adc.h:
../Inc/stm32f446xx_registers.h:
../Inc/stm32f446xx_registers.h:
