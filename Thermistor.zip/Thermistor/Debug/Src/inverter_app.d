Src/inverter_app.o: ../Src/inverter_app.c ../Inc/inverter_app.h \
 ../Inc/soft_start_pwm.h ../Inc/stm32f446xx_registers.h ../Inc/nb_delay.h
../Inc/inverter_app.h:
../Inc/soft_start_pwm.h:
../Inc/stm32f446xx_registers.h:
../Inc/nb_delay.h:
