#ifndef NB_DELAY_H
#define NB_DELAY_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>  /* Defines NULL */

/* --- Hardware Tick Interface --- */
extern volatile uint32_t g_tick_ms;
static inline uint32_t Get_System_Ticks(void) {
    return g_tick_ms;
}

/* ============================================================================
 * TYPE DEFINITIONS
 * ============================================================================ */

/* Stateful Timer Object */
typedef struct {
    uint32_t start_tick;
    uint32_t duration_ms;
    bool     is_running;
} NB_Timer_t;

/* ============================================================================
 * FUNCTION PROTOTYPES
 * ============================================================================ */

/* Core Non-Blocking Delay Functions */
bool NB_Delay_Elapsed(uint32_t *last_tick, uint32_t interval_ms);
void NB_Timer_Start(NB_Timer_t *timer, uint32_t duration_ms);
bool NB_Timer_IsExpired(NB_Timer_t *timer);
void NB_Timer_Stop(NB_Timer_t *timer);
bool NB_Timer_IsRunning(const NB_Timer_t *timer);

/* ============================================================================
 * UNIVERSAL MACRO ENGINE
 * ============================================================================ */

/**
 * @brief  Executes a function non-blockingly every `interval_ms`.
 *         Automatically manages a callsite-isolated static timer instance.
 */
#define delay_nb(task_function, interval_ms) do {             \
    static uint32_t _local_timer = 0;                          \
    if (NB_Delay_Elapsed(&_local_timer, (interval_ms))) {      \
        task_function();                                       \
    }                                                          \
} while(0)

#endif /* NB_DELAY_H */
