#ifndef GPIO_H_
#define GPIO_H_

#include "stm32f446xx_registers.h"

/* Function Prototypes */
void GPIO_Init(void);
void RS485_Set_TX_Mode(void);
void RS485_Set_RX_Mode(void);

#endif /* GPIO_H_ */
