#ifndef VOLTAGE_SENSOR_H
#define VOLTAGE_SENSOR_H

#include <stdint.h>

typedef struct {
    uint32_t raw_adc;
    uint32_t vin_mv;
    uint32_t vout_deci;
} VoltageData_t;

void VoltageSensor_Init(void);
VoltageData_t VoltageSensor_Read(void);
uint8_t VoltageSensor_Test(void);

void VoltageSensor_Init_IT(void);
VoltageData_t VoltageSensor_Read_IT(void);
uint8_t VoltageSensor_DataReady_IT(void);

#endif // VOLTAGE_SENSOR_H
