#ifndef STM32F446XX_REGISTERS_H_
#define STM32F446XX_REGISTERS_H_

#include <stdint.h>

/* ================================================================================= *
 * CORE CORTEX-M4 NVIC DEFINITIONS                                                   *
 * ================================================================================= */
#define NVIC_ISER0_ADDR         (0xE000E100UL)
#define NVIC_ISER0              (*((volatile uint32_t *)NVIC_ISER0_ADDR))

typedef enum {
    ADC_IRQn    = 18,   /* ADC1, ADC2 and ADC3 global interrupts */
    USART1_IRQn = 37    /* USART1 global interrupt */
} IRQn_Type;

static inline void NVIC_EnableIRQ(IRQn_Type IRQn) {
    if ((int32_t)IRQn >= 0) {
        volatile uint32_t *iser = ((volatile uint32_t *)NVIC_ISER0_ADDR) + (((uint32_t)IRQn) >> 5);
        *iser = (1U << (((uint32_t)IRQn) & 0x1FU));
    }
}

/* ================================================================================= *
 * PERIPHERAL BASE ADDRESSES                                                         *
 * ================================================================================= */
#define PERIPH_BASE             (0x40000000UL)
#define APB1PERIPH_BASE         (PERIPH_BASE)
#define APB2PERIPH_BASE         (PERIPH_BASE + 0x00010000UL)
#define AHB1PERIPH_BASE         (PERIPH_BASE + 0x00020000UL)

#define RCC_BASE                (AHB1PERIPH_BASE + 0x3800UL)
#define GPIOA_BASE              (AHB1PERIPH_BASE + 0x0000UL)
#define GPIOB_BASE              (AHB1PERIPH_BASE + 0x0400UL)
#define TIM3_BASE               (APB1PERIPH_BASE + 0x0400UL)
#define USART1_BASE             (APB2PERIPH_BASE + 0x1000UL)
#define ADC1_BASE               (APB2PERIPH_BASE + 0x2000UL)

/* ================================================================================= *
 * REGISTER STRUCTURE DEFINITIONS                                                    *
 * ================================================================================= */
typedef struct {
    volatile uint32_t CR;
    volatile uint32_t PLLCFGR;
    volatile uint32_t CFGR;
    volatile uint32_t CIR;
    volatile uint32_t AHB1RSTR;
    volatile uint32_t AHB2RSTR;
    volatile uint32_t AHB3RSTR;
    uint32_t RESERVED0;
    volatile uint32_t APB1RSTR;
    volatile uint32_t APB2RSTR;
    uint32_t RESERVED1[2];
    volatile uint32_t AHB1ENR;
    volatile uint32_t AHB2ENR;
    volatile uint32_t AHB3ENR;
    uint32_t RESERVED2;
    volatile uint32_t APB1ENR;
    volatile uint32_t APB2ENR;
} RCC_TypeDef;

typedef struct {
    volatile uint32_t MODER;
    volatile uint32_t OTYPER;
    volatile uint32_t OSPEEDR;
    volatile uint32_t PUPDR;
    volatile uint32_t IDR;
    volatile uint32_t ODR;
    volatile uint32_t BSRR;
    volatile uint32_t LCKR;
    volatile uint32_t AFR[2];
} GPIO_TypeDef;

typedef struct {
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t SMCR;
    volatile uint32_t DIER;
    volatile uint32_t SR;
    volatile uint32_t EGR;
    volatile uint32_t CCMR1;
    volatile uint32_t CCMR2;
    volatile uint32_t CCER;
    volatile uint32_t CNT;
    volatile uint32_t PSC;
    volatile uint32_t ARR;
    volatile uint32_t RESERVED0;
    volatile uint32_t CCR1;
    volatile uint32_t CCR2;
    volatile uint32_t CCR3;
    volatile uint32_t CCR4;
    volatile uint32_t RESERVED1;
    volatile uint32_t DCR;
    volatile uint32_t DMAR;
} TIM_TypeDef;

typedef struct {
    volatile uint32_t SR;
    volatile uint32_t DR;
    volatile uint32_t BRR;
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t CR3;
    volatile uint32_t GTPR;
} USART_TypeDef;

typedef struct {
    volatile uint32_t SR;
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t SMPR1;
    volatile uint32_t SMPR2;
    volatile uint32_t JOFR1;
    volatile uint32_t JOFR2;
    volatile uint32_t JOFR3;
    volatile uint32_t JOFR4;
    volatile uint32_t HTR;
    volatile uint32_t LTR;
    volatile uint32_t SQR1;
    volatile uint32_t SQR2;
    volatile uint32_t SQR3;
    volatile uint32_t JSQR;
    volatile uint32_t JDR1;
    volatile uint32_t JDR2;
    volatile uint32_t JDR3;
    volatile uint32_t JDR4;
    volatile uint32_t DR;
} ADC_TypeDef;

/* Peripheral Instantiations */
#define RCC                     ((RCC_TypeDef *) RCC_BASE)
#define GPIOA                   ((GPIO_TypeDef *) GPIOA_BASE)
#define GPIOB                   ((GPIO_TypeDef *) GPIOB_BASE)
#define TIM3                    ((TIM_TypeDef *) TIM3_BASE)
#define USART1                  ((USART_TypeDef *) USART1_BASE)
#define ADC1                    ((ADC_TypeDef *) ADC1_BASE)

/* RCC Bit Masks */
#define RCC_AHB1ENR_GPIOAEN     (1U << 0)
#define RCC_AHB1ENR_GPIOBEN     (1U << 1)
#define RCC_APB1ENR_TIM3EN      (1U << 1)
#define RCC_APB2ENR_USART1EN    (1U << 4)
#define RCC_APB2ENR_ADC1EN      (1U << 8)

/* ADC Bit Masks */
#define ADC_CR1_EOCIE           (1U << 5)
#define ADC_CR2_ADON            (1U << 0)
#define ADC_CR2_SWSTART         (1U << 30)
#define ADC_SR_EOC              (1U << 1)

/* USART Bit Masks */
#define USART_SR_TXE            (1U << 7)
#define USART_SR_TC             (1U << 6)
#define USART_SR_RXNE           (1U << 5)
#define USART_CR1_UE            (1U << 13)
#define USART_CR1_TXEIE         (1U << 7)
#define USART_CR1_RXNEIE        (1U << 5)
#define USART_CR1_TE            (1U << 3)
#define USART_CR1_RE            (1U << 2)

#endif /* STM32F446XX_REGISTERS_H_ */
