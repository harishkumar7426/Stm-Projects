#ifndef CURRENT_SENSOR_H
#define CURRENT_SENSOR_H

#include <stdint.h>

typedef struct {
    uint32_t raw_adc;
    uint32_t iin_mv;
    uint32_t iout_deci;
} CurrentData_t;

void CurrentSensor_Init(void);
CurrentData_t CurrentSensor_Read(void);
uint8_t CurrentSensor_Test(void);

void CurrentSensor_Init_IT(void);
CurrentData_t CurrentSensor_Read_IT(void);
uint8_t CurrentSensor_DataReady_IT(void);

#endif // CURRENT_SENSOR_H
