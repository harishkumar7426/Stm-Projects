#ifndef ADC_H
#define ADC_H

#include "stm32f446xx_registers.h"

/* --- Polling API (unchanged) --- */
void ADC1_IN0_Init(void);
uint32_t ADC1_Read_IN0(void);

void ADC1_IN1_Init(void);
uint32_t ADC1_Read_IN1(void);

void ADC1_IN2_Init(void);
uint32_t ADC1_Read_IN2(void);

/* --- Self-test --- */
uint8_t ADC1_Test(void);

/* --- Interrupt-driven round-robin scan (channels 0,1,2) --- */
void ADC1_IT_Init(void);
void ADC1_IT_Start(void);
uint32_t ADC1_IT_GetValue(uint8_t channel);
uint8_t ADC1_IT_DataReady(uint8_t channel);

#endif // ADC_H
