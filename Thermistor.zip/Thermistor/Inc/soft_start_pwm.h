#ifndef SOFT_START_PWM_H
#define SOFT_START_PWM_H

#include "stm32f446xx_registers.h"
#include <stdint.h>

#define MCU_CLOCK_FREQ_HZ    16000000U  // System Core Clock (16 MHz)

// Soft-Start & Soft-Stop Duty Cycle Bounds
#define SOFTSTART_RAMP_START_PCT   10U  // Start Duty Cycle (10%)
#define SOFTSTART_RAMP_END_PCT     80U  // Target Duty Cycle (80%)
#define SOFTSTART_RAMP_FINAL_PCT   90U  // Final Steady State (90%)
#define SOFTSTART_HOLD_TIME_SEC    10U  // Hold Time at 80% (10 Seconds)

typedef enum {
    PIN_PA6_CH1 = 1,
    PIN_PA7_CH2 = 2,
    PIN_PB0_CH3 = 3,
    PIN_PB1_CH4 = 4
} PWM_Pin_t;

typedef struct {
    PWM_Pin_t M1_Pin; // Leg A High-Side
    PWM_Pin_t M2_Pin; // Leg A Low-Side
    PWM_Pin_t M3_Pin; // Leg B High-Side
    PWM_Pin_t M4_Pin; // Leg B Low-Side
} Inverter_PinMap_t;

/* Non-blocking state machine states */
typedef enum {
    SS_STATE_IDLE = 0,

    /* Soft-start path */
    SS_STATE_START_HOLD,
    SS_STATE_RAMP_PAIR14_UP,
    SS_STATE_HOLD_PAIR14,
    SS_STATE_START_HOLD_PAIR23,
    SS_STATE_RAMP_PAIR23_UP,
    SS_STATE_HOLD_PAIR23,
    SS_STATE_COMPLETE,

    /* Soft-stop path */
    SS_STATE_STOP_RAMP_PAIR23_DOWN,
    SS_STATE_STOP_GAP,
    SS_STATE_STOP_RAMP_PAIR14_DOWN,
    SS_STATE_STOPPED,

    /* Emergency */
    SS_STATE_ESTOP
} SoftStart_State_t;

/* Global tick counter */
extern volatile uint32_t g_tick_ms;

/* Separate Non-blocking Delay Function */
uint8_t Has_Timeout_Elapsed(uint32_t *last_time, uint32_t interval_ms);

/* ------------------------------------------------------------------------ *
 * General-purpose manual non-blocking delay utility.                      *
 * Unlike Has_Timeout_Elapsed (caller owns a single "last_time" variable    *
 * and must re-arm it manually), this is a self-contained timer object:    *
 * Start() it once, then IsExpired()/IsRunning() it from anywhere, as many  *
 * independent instances as needed, without them interfering with each     *
 * other. Hand-rolled off g_tick_ms; never blocks the caller.               *
 * ------------------------------------------------------------------------ */
typedef struct {
    uint32_t start_tick;
    uint32_t duration_ms;
    uint8_t  active;   /* 0 = not running / already consumed, 1 = running */
} NonBlockingDelay_t;

/* Arms the timer to expire duration_ms from now. */
void NonBlockingDelay_Start(NonBlockingDelay_t *timer, uint32_t duration_ms);

/* Returns 1 exactly once, the first call after the duration has elapsed
 * (auto-clears 'active' so it won't keep reporting expired). Returns 0
 * while still running, or if never started / already consumed. */
uint8_t NonBlockingDelay_IsExpired(NonBlockingDelay_t *timer);

/* Returns 1 if the timer is currently counting down. Does not consume it. */
uint8_t NonBlockingDelay_IsRunning(NonBlockingDelay_t *timer);

/* Cancels the timer early; IsExpired()/IsRunning() both read 0 afterward
 * until Start() is called again. */
void NonBlockingDelay_Stop(NonBlockingDelay_t *timer);

/* Configuration & Hardware Init */
void SoftStart_SetFreqDeadTime(uint32_t SF, uint32_t dt);
void SoftStart_PWM_Init(Inverter_PinMap_t pin_config);
void SoftStart_SysTick_Init(uint32_t cpu_freq_hz);

/* Non-blocking operational control */
void SoftStart_Inverter_Begin(uint32_t ramp_duration_sec);
void SoftStop_Inverter_Begin(uint32_t ramp_duration_sec);
void SoftStart_Process(void);
SoftStart_State_t SoftStart_GetState(void);

/* Instantaneous Hardware Emergency Stop */
void EmergencyStop_Inverter_Execute(void);

#endif /* SOFT_START_PWM_H */
