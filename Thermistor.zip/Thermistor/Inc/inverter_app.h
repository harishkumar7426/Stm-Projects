#ifndef INVERTER_APP_H
#define INVERTER_APP_H

#include "soft_start_pwm.h"
#include "nb_delay.h"

/* 8-Bit UART Stop Command Byte */
#define CMD_STOP_INVERTER   0x12

/* ============================================================================
 * APPLICATION LEVEL APIs
 * ============================================================================ */

/**
 * @brief Initializes User Button (PC13), UART2 Interrupts, and TIM3 PWM pins.
 */
void Inverter_App_Init(void);

/**
 * @brief Starts the inverter soft-start ramp-up and enables system SysTick.
 * @param ramp_duration_sec Duration of initial soft-start ramp in seconds.
 */
void Inverter_App_Start(uint32_t ramp_duration_sec);

/**
 * @brief Triggers a rapid 1-second soft-stop ramp down (Emergency Ramp Stop).
 */
void Inverter_App_TriggerEmergencyStop(void);

/**
 * @brief Triggers a normal 3-second soft-stop ramp down (Normal Ramp Stop).
 */
void Inverter_App_TriggerNormalStop(void);

/**
 * @brief Instantly cuts off PWM signals immediately (Hardware E-Stop).
 */
void Inverter_App_TriggerInstantStop(void);

/**
 * @brief Configures ARM Cortex-M SLEEPONEXIT for low-power operation.
 */
void Inverter_App_EnableAutoSleep(void);

#endif /* INVERTER_APP_H */
