#ifndef UART_H_
#define UART_H_

#include "stm32f446xx_registers.h"

/* --- Polling API (unchanged) --- */
void USART1_Init(void);
void USART1_WriteChar(char c);
void USART1_WriteString(const char *str);
char USART1_ReadChar_Timeout(uint32_t timeout_loops);
void USART1_WaitTransmissionComplete(void);

/* --- Self-test --- */
uint8_t USART1_Test(void);

/* --- Interrupt-driven RX --- */
void USART1_Init_IT(void);
uint8_t USART1_RxAvailable(void);
char USART1_RxRead(void);

#endif /* UART_H_ */
