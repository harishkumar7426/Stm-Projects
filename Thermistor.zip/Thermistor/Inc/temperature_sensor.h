#ifndef TEMP_SENSOR_H
#define TEMP_SENSOR_H

#include <stdint.h>

typedef struct {
    uint32_t raw_adc;
    uint32_t tin_mv;
    uint32_t temp_deci;
} TempData_t;

void TempSensor_Init(void);
TempData_t TempSensor_Read(void);
uint8_t TempSensor_Test(void);

void TempSensor_Init_IT(void);
TempData_t TempSensor_Read_IT(void);
uint8_t TempSensor_DataReady_IT(void);

#endif
