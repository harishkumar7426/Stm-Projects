#include <stdint.h>

extern uint32_t _estack;
extern uint32_t _sidata;
extern uint32_t _sdata;
extern uint32_t _edata;
extern uint32_t _sbss;
extern uint32_t _ebss;

extern int main(void);

#define SCB_CPACR (*(volatile uint32_t *)0xE000ED88)

void Reset_Handler(void);
void Default_Handler(void);

/* ---- Core Cortex-M4 exceptions (fixed positions, all MCUs) ---- */
void NMI_Handler(void)            __attribute__((weak, alias("Default_Handler")));
void HardFault_Handler(void)      __attribute__((weak, alias("Default_Handler")));
void MemManage_Handler(void)      __attribute__((weak, alias("Default_Handler")));
void BusFault_Handler(void)       __attribute__((weak, alias("Default_Handler")));
void UsageFault_Handler(void)     __attribute__((weak, alias("Default_Handler")));
void SVC_Handler(void)            __attribute__((weak, alias("Default_Handler")));
void DebugMon_Handler(void)       __attribute__((weak, alias("Default_Handler")));
void PendSV_Handler(void)         __attribute__((weak, alias("Default_Handler")));
void SysTick_Handler(void)        __attribute__((weak, alias("Default_Handler")));

/* ---- STM32F446xx peripheral IRQs (RM0390 Table 38 vector table) ----
 * Every handler is weak-aliased to Default_Handler by default. To actually
 * use one, define a real (non-weak) function with the exact same name
 * anywhere in your project -- the linker will pick your real one over the
 * weak alias automatically. This list covers IRQ0 through IRQ81 (FPU),
 * i.e. everything except the F446-unique tail (UART7/8, SPI4-6, SAI1/2,
 * QUADSPI, CEC, SPDIF_RX, FMPI2C1) -- add those the same way, by index,
 * if you end up using them; double check their exact IRQ numbers against
 * RM0390 Table 38 first, since I'm less certain of that tail end. */
void WWDG_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ0
void PVD_IRQHandler(void)                 __attribute__((weak, alias("Default_Handler")));               // IRQ1
void TAMP_STAMP_IRQHandler(void)          __attribute__((weak, alias("Default_Handler")));               // IRQ2
void RTC_WKUP_IRQHandler(void)            __attribute__((weak, alias("Default_Handler")));               // IRQ3
void FLASH_IRQHandler(void)               __attribute__((weak, alias("Default_Handler")));               // IRQ4
void RCC_IRQHandler(void)                 __attribute__((weak, alias("Default_Handler")));               // IRQ5
void EXTI0_IRQHandler(void)               __attribute__((weak, alias("Default_Handler")));               // IRQ6
void EXTI1_IRQHandler(void)               __attribute__((weak, alias("Default_Handler")));               // IRQ7
void EXTI2_IRQHandler(void)               __attribute__((weak, alias("Default_Handler")));               // IRQ8
void EXTI3_IRQHandler(void)               __attribute__((weak, alias("Default_Handler")));               // IRQ9
void EXTI4_IRQHandler(void)               __attribute__((weak, alias("Default_Handler")));               // IRQ10
void DMA1_Stream0_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ11
void DMA1_Stream1_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ12
void DMA1_Stream2_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ13
void DMA1_Stream3_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ14
void DMA1_Stream4_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ15
void DMA1_Stream5_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ16
void DMA1_Stream6_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ17
void ADC_IRQHandler(void)                 __attribute__((weak, alias("Default_Handler")));               // IRQ18
void CAN1_TX_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ19
void CAN1_RX0_IRQHandler(void)            __attribute__((weak, alias("Default_Handler")));               // IRQ20
void CAN1_RX1_IRQHandler(void)            __attribute__((weak, alias("Default_Handler")));               // IRQ21
void CAN1_SCE_IRQHandler(void)            __attribute__((weak, alias("Default_Handler")));               // IRQ22
void EXTI9_5_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ23
void TIM1_BRK_TIM9_IRQHandler(void)       __attribute__((weak, alias("Default_Handler")));               // IRQ24
void TIM1_UP_TIM10_IRQHandler(void)       __attribute__((weak, alias("Default_Handler")));               // IRQ25
void TIM1_TRG_COM_TIM11_IRQHandler(void)  __attribute__((weak, alias("Default_Handler")));               // IRQ26
void TIM1_CC_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ27
void TIM2_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ28
void TIM3_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ29
void TIM4_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ30
void I2C1_EV_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ31
void I2C1_ER_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ32
void I2C2_EV_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ33
void I2C2_ER_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ34
void SPI1_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ35
void SPI2_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ36
void USART1_IRQHandler(void)              __attribute__((weak, alias("Default_Handler")));               // IRQ37
void USART2_IRQHandler(void)              __attribute__((weak, alias("Default_Handler")));               // IRQ38  <-- your stop command needs this one
void USART3_IRQHandler(void)              __attribute__((weak, alias("Default_Handler")));               // IRQ39
void EXTI15_10_IRQHandler(void)           __attribute__((weak, alias("Default_Handler")));               // IRQ40
void RTC_Alarm_IRQHandler(void)           __attribute__((weak, alias("Default_Handler")));               // IRQ41
void OTG_FS_WKUP_IRQHandler(void)         __attribute__((weak, alias("Default_Handler")));               // IRQ42
void TIM8_BRK_TIM12_IRQHandler(void)      __attribute__((weak, alias("Default_Handler")));               // IRQ43
void TIM8_UP_TIM13_IRQHandler(void)       __attribute__((weak, alias("Default_Handler")));               // IRQ44
void TIM8_TRG_COM_TIM14_IRQHandler(void)  __attribute__((weak, alias("Default_Handler")));               // IRQ45
void TIM8_CC_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ46
void DMA1_Stream7_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ47
void FMC_IRQHandler(void)                 __attribute__((weak, alias("Default_Handler")));               // IRQ48
void SDIO_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ49
void TIM5_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ50
void SPI3_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ51
void UART4_IRQHandler(void)               __attribute__((weak, alias("Default_Handler")));               // IRQ52
void UART5_IRQHandler(void)               __attribute__((weak, alias("Default_Handler")));               // IRQ53
void TIM6_DAC_IRQHandler(void)            __attribute__((weak, alias("Default_Handler")));               // IRQ54
void TIM7_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ55
void DMA2_Stream0_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ56
void DMA2_Stream1_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ57
void DMA2_Stream2_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ58
void DMA2_Stream3_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ59
void DMA2_Stream4_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ60
void CAN2_TX_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ63
void CAN2_RX0_IRQHandler(void)            __attribute__((weak, alias("Default_Handler")));               // IRQ64
void CAN2_RX1_IRQHandler(void)            __attribute__((weak, alias("Default_Handler")));               // IRQ65
void CAN2_SCE_IRQHandler(void)            __attribute__((weak, alias("Default_Handler")));               // IRQ66
void OTG_FS_IRQHandler(void)              __attribute__((weak, alias("Default_Handler")));               // IRQ67
void DMA2_Stream5_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ68
void DMA2_Stream6_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ69
void DMA2_Stream7_IRQHandler(void)        __attribute__((weak, alias("Default_Handler")));               // IRQ70
void USART6_IRQHandler(void)              __attribute__((weak, alias("Default_Handler")));               // IRQ71
void I2C3_EV_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ72
void I2C3_ER_IRQHandler(void)             __attribute__((weak, alias("Default_Handler")));               // IRQ73
void OTG_HS_EP1_OUT_IRQHandler(void)      __attribute__((weak, alias("Default_Handler")));               // IRQ74
void OTG_HS_EP1_IN_IRQHandler(void)       __attribute__((weak, alias("Default_Handler")));               // IRQ75
void OTG_HS_WKUP_IRQHandler(void)         __attribute__((weak, alias("Default_Handler")));               // IRQ76
void OTG_HS_IRQHandler(void)              __attribute__((weak, alias("Default_Handler")));               // IRQ77
void DCMI_IRQHandler(void)                __attribute__((weak, alias("Default_Handler")));               // IRQ78
void RNG_IRQHandler(void)                 __attribute__((weak, alias("Default_Handler")));               // IRQ80
void FPU_IRQHandler(void)                 __attribute__((weak, alias("Default_Handler")));               // IRQ81

#define VECTOR_TABLE_SIZE (16 + 82)  /* 16 core exceptions + IRQ0..IRQ81 */

__attribute__((section(".isr_vector")))
void (* const g_pfnVectorTable[VECTOR_TABLE_SIZE])(void) = {
    /* ---- Core exceptions: positions are FIXED, never change these ---- */
    [0]  = (void (*)(void))&_estack,
    [1]  = Reset_Handler,
    [2]  = NMI_Handler,
    [3]  = HardFault_Handler,
    [4]  = MemManage_Handler,
    [5]  = BusFault_Handler,
    [6]  = UsageFault_Handler,
    [11] = SVC_Handler,
    [12] = DebugMon_Handler,
    [14] = PendSV_Handler,
    [15] = SysTick_Handler,

    /* ---- Peripheral IRQs: index = 16 + IRQ number ----
     * Using [index] = handler means the compiler places each handler at
     * its exact required slot regardless of how many lines are above it,
     * so miscounting commas can never silently misalign this table again. */
    [16 + 0]  = WWDG_IRQHandler,
    [16 + 1]  = PVD_IRQHandler,
    [16 + 2]  = TAMP_STAMP_IRQHandler,
    [16 + 3]  = RTC_WKUP_IRQHandler,
    [16 + 4]  = FLASH_IRQHandler,
    [16 + 5]  = RCC_IRQHandler,
    [16 + 6]  = EXTI0_IRQHandler,
    [16 + 7]  = EXTI1_IRQHandler,
    [16 + 8]  = EXTI2_IRQHandler,
    [16 + 9]  = EXTI3_IRQHandler,
    [16 + 10] = EXTI4_IRQHandler,
    [16 + 11] = DMA1_Stream0_IRQHandler,
    [16 + 12] = DMA1_Stream1_IRQHandler,
    [16 + 13] = DMA1_Stream2_IRQHandler,
    [16 + 14] = DMA1_Stream3_IRQHandler,
    [16 + 15] = DMA1_Stream4_IRQHandler,
    [16 + 16] = DMA1_Stream5_IRQHandler,
    [16 + 17] = DMA1_Stream6_IRQHandler,
    [16 + 18] = ADC_IRQHandler,
    [16 + 19] = CAN1_TX_IRQHandler,
    [16 + 20] = CAN1_RX0_IRQHandler,
    [16 + 21] = CAN1_RX1_IRQHandler,
    [16 + 22] = CAN1_SCE_IRQHandler,
    [16 + 23] = EXTI9_5_IRQHandler,
    [16 + 24] = TIM1_BRK_TIM9_IRQHandler,
    [16 + 25] = TIM1_UP_TIM10_IRQHandler,
    [16 + 26] = TIM1_TRG_COM_TIM11_IRQHandler,
    [16 + 27] = TIM1_CC_IRQHandler,
    [16 + 28] = TIM2_IRQHandler,
    [16 + 29] = TIM3_IRQHandler,
    [16 + 30] = TIM4_IRQHandler,
    [16 + 31] = I2C1_EV_IRQHandler,
    [16 + 32] = I2C1_ER_IRQHandler,
    [16 + 33] = I2C2_EV_IRQHandler,
    [16 + 34] = I2C2_ER_IRQHandler,
    [16 + 35] = SPI1_IRQHandler,
    [16 + 36] = SPI2_IRQHandler,
    [16 + 37] = USART1_IRQHandler,
    [16 + 38] = USART2_IRQHandler,   /* <-- this was completely missing before */
    [16 + 39] = USART3_IRQHandler,
    [16 + 40] = EXTI15_10_IRQHandler,
    [16 + 41] = RTC_Alarm_IRQHandler,
    [16 + 42] = OTG_FS_WKUP_IRQHandler,
    [16 + 43] = TIM8_BRK_TIM12_IRQHandler,
    [16 + 44] = TIM8_UP_TIM13_IRQHandler,
    [16 + 45] = TIM8_TRG_COM_TIM14_IRQHandler,
    [16 + 46] = TIM8_CC_IRQHandler,
    [16 + 47] = DMA1_Stream7_IRQHandler,
    [16 + 48] = FMC_IRQHandler,
    [16 + 49] = SDIO_IRQHandler,
    [16 + 50] = TIM5_IRQHandler,
    [16 + 51] = SPI3_IRQHandler,
    [16 + 52] = UART4_IRQHandler,
    [16 + 53] = UART5_IRQHandler,
    [16 + 54] = TIM6_DAC_IRQHandler,
    [16 + 55] = TIM7_IRQHandler,
    [16 + 56] = DMA2_Stream0_IRQHandler,
    [16 + 57] = DMA2_Stream1_IRQHandler,
    [16 + 58] = DMA2_Stream2_IRQHandler,
    [16 + 59] = DMA2_Stream3_IRQHandler,
    [16 + 60] = DMA2_Stream4_IRQHandler,
    [16 + 63] = CAN2_TX_IRQHandler,
    [16 + 64] = CAN2_RX0_IRQHandler,
    [16 + 65] = CAN2_RX1_IRQHandler,
    [16 + 66] = CAN2_SCE_IRQHandler,
    [16 + 67] = OTG_FS_IRQHandler,
    [16 + 68] = DMA2_Stream5_IRQHandler,
    [16 + 69] = DMA2_Stream6_IRQHandler,
    [16 + 70] = DMA2_Stream7_IRQHandler,
    [16 + 71] = USART6_IRQHandler,
    [16 + 72] = I2C3_EV_IRQHandler,
    [16 + 73] = I2C3_ER_IRQHandler,
    [16 + 74] = OTG_HS_EP1_OUT_IRQHandler,
    [16 + 75] = OTG_HS_EP1_IN_IRQHandler,
    [16 + 76] = OTG_HS_WKUP_IRQHandler,
    [16 + 77] = OTG_HS_IRQHandler,
    [16 + 78] = DCMI_IRQHandler,
    [16 + 80] = RNG_IRQHandler,
    [16 + 81] = FPU_IRQHandler,
};

void Default_Handler(void) {
    while (1) { }
}

void Reset_Handler(void) {
    uint32_t *src = &_sidata;
    uint32_t *dst = &_sdata;
    while (dst < &_edata) {
        *dst++ = *src++;
    }

    dst = &_sbss;
    while (dst < &_ebss) {
        *dst++ = 0;
    }

    SCB_CPACR |= (0xFU << 20);
    __asm__ volatile ("DSB");
    __asm__ volatile ("ISB");

    main();

    while (1) { }
}
