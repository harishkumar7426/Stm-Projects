#include "gpio.h"

void GPIO_Init(void) {
    // Enable GPIOA Clock (AHB1 Bus)
    RCC->AHB1ENR |= (1U << 0);

    // PA4: Output mode (01) - RS485 DE/RE
    GPIOA->MODER &= ~(3U << (4 * 2));
    GPIOA->MODER |=  (1U << (4 * 2));

    // PA9 (TX): Alternate Function mode (10)
    GPIOA->MODER &= ~(3U << (9 * 2));
    GPIOA->MODER |=  (2U << (9 * 2));

    // PA10 (RX): Alternate Function mode (10)
    GPIOA->MODER &= ~(3U << (10 * 2));
    GPIOA->MODER |=  (2U << (10 * 2));

    // PA9, PA10: High speed (11) — cleaner edges for UART
    GPIOA->OSPEEDR |= (3U << (9 * 2));
    GPIOA->OSPEEDR |= (3U << (10 * 2));

    // AF7 (USART1) for PA9 & PA10
    GPIOA->AFR[1] &= ~(0xFU << ((9 - 8) * 4));
    GPIOA->AFR[1] |=  (7U   << ((9 - 8) * 4));

    GPIOA->AFR[1] &= ~(0xFU << ((10 - 8) * 4));
    GPIOA->AFR[1] |=  (7U   << ((10 - 8) * 4));
}

void RS485_Set_TX_Mode(void) {
    GPIOA->ODR |= (1U << 4); // PA4 HIGH
}

void RS485_Set_RX_Mode(void) {
    GPIOA->ODR &= ~(1U << 4); // PA4 LOW
}
