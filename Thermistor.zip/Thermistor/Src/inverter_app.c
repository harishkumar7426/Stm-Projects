#include "inverter_app.h"

/* Direct Hardware Register Definitions */
#define DBGMCU_CR           (*(volatile uint32_t *)0xE0042004UL)
#define DBGMCU_CR_DBG_SLEEP (1U << 0)

#define RCC_AHB1ENR         (*(volatile uint32_t *)0x40023830UL)
#define RCC_APB1ENR         (*(volatile uint32_t *)0x40023840UL)

/* ARM Cortex-M System Control Register */
#define SCB_SCR             (*(volatile uint32_t *)0xE000ED10UL)
#define SCB_SCR_SLEEPONEXIT (1U << 1)

/* GPIO Register Map */
#define GPIOA_MODER         (*(volatile uint32_t *)0x40020000UL)
#define GPIOA_AFRL          (*(volatile uint32_t *)0x40020020UL)
#define GPIOC_MODER         (*(volatile uint32_t *)0x40020800UL)
#define GPIOC_PUPDR         (*(volatile uint32_t *)0x4002080CUL)
#define GPIOC_IDR           (*(volatile uint32_t *)0x40020810UL)

/* USART2 Register Map */
#define USART2_SR           (*(volatile uint32_t *)0x40004400UL)
#define USART2_DR           (*(volatile uint32_t *)0x40004404UL)
#define USART2_BRR          (*(volatile uint32_t *)0x40004408UL)
#define USART2_CR1          (*(volatile uint32_t *)0x4000440CUL)

/* NVIC Interrupt Registers */
#define NVIC_ISER1          (*(volatile uint32_t *)0xE000E104UL)
#define NVIC_IPR_BASE       ((volatile uint8_t  *)0xE000E400UL)

/* Shared State Variable */
static volatile uint8_t stop_requested = 0;

/* Internal Peripheral Initialization Routines */
static void GPIO_Init_User_Button(void) {
    RCC_AHB1ENR |= (1U << 2);
    GPIOC_MODER &= ~(3U << (13 * 2));
    GPIOC_PUPDR &= ~(3U << (13 * 2));
    GPIOC_PUPDR |=  (1U << (13 * 2));
}

static void UART2_Init_Interrupt(void) {
    RCC_AHB1ENR |= (1U << 0);
    RCC_APB1ENR |= (1U << 17);

    GPIOA_MODER &= ~((3U << (2 * 2)) | (3U << (3 * 2)));
    GPIOA_MODER |=  ((2U << (2 * 2)) | (2U << (3 * 2)));

    GPIOA_AFRL  &= ~((0xFU << (2 * 4)) | (0xFU << (3 * 4)));
    GPIOA_AFRL  |=  ((7U  << (2 * 4)) | (7U  << (3 * 4)));

    USART2_BRR = 0x008B;

    volatile uint32_t dummy_sr = USART2_SR;
    volatile uint8_t  dummy_dr = (uint8_t)(USART2_DR & 0xFF);
    (void)dummy_sr;
    (void)dummy_dr;

    NVIC_IPR_BASE[38] = (2U << 4);
    USART2_CR1 |= (1U << 2) | (1U << 5) | (1U << 13);
    NVIC_ISER1 |= (1U << (38 - 32));
}

static inline void Check_Safety_Sensors(void) {
    /* Insert over-current, ADC, or temperature sensor fault checks here */
}

/* ============================================================================
 * PUBLIC REUSABLE CONTROL APIs
 * ============================================================================ */

void Inverter_App_Init(void) {
    DBGMCU_CR |= DBGMCU_CR_DBG_SLEEP;
    stop_requested = 0;

    GPIO_Init_User_Button();
    UART2_Init_Interrupt();

    Inverter_PinMap_t my_pins = {
        .M1_Pin = PIN_PA6_CH1,
        .M2_Pin = PIN_PA7_CH2,
        .M3_Pin = PIN_PB0_CH3,
        .M4_Pin = PIN_PB1_CH4
    };

    SoftStart_PWM_Init(my_pins);
    SoftStart_SetFreqDeadTime(85000, 250);
}

void Inverter_App_Start(uint32_t ramp_duration_sec) {
    SoftStart_Inverter_Begin(ramp_duration_sec);
    SoftStart_SysTick_Init(MCU_CLOCK_FREQ_HZ);
}

void Inverter_App_TriggerEmergencyStop(void) {
    if (!stop_requested) {
        SoftStop_Inverter_Begin(1); // Rapid 1-second ramp stop
        stop_requested = 1;
    }
}

void Inverter_App_TriggerNormalStop(void) {
    if (!stop_requested) {
        SoftStop_Inverter_Begin(3); // Normal 3-second ramp stop
        stop_requested = 1;
    }
}

void Inverter_App_TriggerInstantStop(void) {
    EmergencyStop_Inverter_Execute(); // Hardware immediate shutoff
    stop_requested = 1;
}

void Inverter_App_EnableAutoSleep(void) {
    SCB_SCR |= SCB_SCR_SLEEPONEXIT;
}

/* ============================================================================
 * TASK SCHEDULING & INTERRUPT HANDLERS
 * ============================================================================ */

void Task_Check_Inverter_Status(void) {
    if (SoftStart_GetState() != SS_STATE_ESTOP) {
        if (SoftStart_GetState() == SS_STATE_COMPLETE && !stop_requested) {
            Inverter_App_TriggerNormalStop();
        }
    }
}

void Task_Read_User_Button(void) {
    static uint8_t button_last_state = 0xFF;
    uint8_t button_current_state = (GPIOC_IDR & (1U << 13)) ? 1 : 0;

    if (button_last_state == 0xFF) {
        button_last_state = button_current_state;
        return;
    }

    if (button_last_state == 1 && button_current_state == 0) {
        Inverter_App_TriggerEmergencyStop();
    }

    button_last_state = button_current_state;
}

void USART2_IRQHandler(void) {
    volatile uint32_t sr = USART2_SR;
    volatile uint8_t rx_command = (uint8_t)(USART2_DR & 0xFF);

    if (sr & (1U << 5)) {
        if (rx_command == CMD_STOP_INVERTER) {
            Inverter_App_TriggerEmergencyStop();
        }
    }
}

void SysTick_Handler(void) {
    g_tick_ms++;

    Check_Safety_Sensors();
    SoftStart_Process();
    delay_nb(Task_Check_Inverter_Status, 100);
    delay_nb(Task_Read_User_Button, 20);
}
