#include "inverter_app.h"

int main(void) {
    /* 1. Initialize Peripherals (GPIO Button, UART Interrupt, TIM3 PWM) */
    Inverter_App_Init();

    /* 2. Begin 5-second Soft-Start Ramp Sequence & SysTick Scheduler */
    Inverter_App_Start(5);

    /* 3. Enable Hardware Auto-Sleep on ISR Exit */
    Inverter_App_EnableAutoSleep();

    /* 4. Enter Sleep Mode (System is fully event & interrupt driven) */
    __asm__("wfi");

    return 0;
}
