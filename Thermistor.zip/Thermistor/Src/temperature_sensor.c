#include "temperature_sensor.h"
#include "adc.h"

/* =========================================================
 * 1. INITIALIZATION
 * ========================================================= */
void TempSensor_Init(void) {
    ADC1_IN2_Init();
}

/* =========================================================
 * 2. SELF TEST
 * ========================================================= */
uint8_t TempSensor_Test(void) {
    TempData_t t_data = TempSensor_Read();
    if (t_data.raw_adc > 4095) return 0;
    return 1;
}

/* =========================================================
 * 3. READ
 * ========================================================= */
TempData_t TempSensor_Read(void) {
    TempData_t t_data;
    t_data.raw_adc = ADC1_Read_IN2();
    t_data.tin_mv = (t_data.raw_adc * 3300) / 4095;
    t_data.temp_deci = (t_data.raw_adc * 1000) / 4095;
    return t_data;
}

/* =========================================================
 * 4. INTERRUPT CONTROL
 * ========================================================= */
void TempSensor_Init_IT(void) {
    ADC1_IT_Init();
}

uint8_t TempSensor_DataReady_IT(void) {
    return ADC1_IT_DataReady(2);
}

/* =========================================================
 * 5. INTERRUPT HANDLER
 * (handled centrally in adc.c -> ADC_IRQHandler;
 *  this wrapper just reads the latest IT-scanned value)
 * ========================================================= */
TempData_t TempSensor_Read_IT(void) {
    TempData_t t_data;
    t_data.raw_adc = ADC1_IT_GetValue(2);
    t_data.tin_mv = (t_data.raw_adc * 3300) / 4095;
    t_data.temp_deci = (t_data.raw_adc * 1000) / 4095;
    return t_data;
}
