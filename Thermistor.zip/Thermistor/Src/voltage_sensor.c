#include "voltage_sensor.h"
#include "adc.h"

/* =========================================================
 * 1. INITIALIZATION
 * ========================================================= */
void VoltageSensor_Init(void) {
    ADC1_IN0_Init();
}

/* =========================================================
 * 2. SELF TEST
 * ========================================================= */
uint8_t VoltageSensor_Test(void) {
    VoltageData_t v_data = VoltageSensor_Read();
    if (v_data.raw_adc > 4095) return 0;
    return 1;
}

/* =========================================================
 * 3. READ
 * ========================================================= */
VoltageData_t VoltageSensor_Read(void) {
    VoltageData_t v_data;
    v_data.raw_adc = ADC1_Read_IN0();
    v_data.vin_mv = (v_data.raw_adc * 3300) / 4095;
    v_data.vout_deci = (v_data.raw_adc * 12000) / 4095;
    return v_data;
}

/* =========================================================
 * 4. INTERRUPT CONTROL
 * ========================================================= */
void VoltageSensor_Init_IT(void) {
    ADC1_IT_Init();
}

uint8_t VoltageSensor_DataReady_IT(void) {
    return ADC1_IT_DataReady(0);
}

/* =========================================================
 * 5. INTERRUPT HANDLER
 * (handled centrally in adc.c -> ADC_IRQHandler;
 *  this wrapper just reads the latest IT-scanned value)
 * ========================================================= */
VoltageData_t VoltageSensor_Read_IT(void) {
    VoltageData_t v_data;
    v_data.raw_adc = ADC1_IT_GetValue(0);
    v_data.vin_mv = (v_data.raw_adc * 3300) / 4095;
    v_data.vout_deci = (v_data.raw_adc * 12000) / 4095;
    return v_data;
}
