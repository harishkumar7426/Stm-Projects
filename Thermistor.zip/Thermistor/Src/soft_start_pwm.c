#include "soft_start_pwm.h"

volatile uint32_t g_tick_ms = 0;

static uint32_t active_frequency_hz = 85000; // Default 85 kHz
static uint32_t active_deadtime_ns  = 250;   // Default 250 ns
static Inverter_PinMap_t active_map;
static uint16_t timer_arr = 0;

/* ---- Non-blocking state machine bookkeeping ---- */
static SoftStart_State_t current_state    = SS_STATE_IDLE;
static uint32_t          state_tick_target = 0;
static uint32_t          step_delay_ms      = 0;
static int16_t           current_pct        = 0;

/* Separate Non-blocking Delay Function Implementation */
uint8_t Has_Timeout_Elapsed(uint32_t *last_time, uint32_t interval_ms) {
    if ((g_tick_ms - *last_time) >= interval_ms) {
        *last_time = g_tick_ms;
        return 1;
    }
    return 0;
}

/* General-purpose manual non-blocking delay utility implementation. */
void NonBlockingDelay_Start(NonBlockingDelay_t *timer, uint32_t duration_ms) {
    timer->start_tick  = g_tick_ms;
    timer->duration_ms = duration_ms;
    timer->active      = 1U;
}

uint8_t NonBlockingDelay_IsExpired(NonBlockingDelay_t *timer) {
    if (!timer->active) {
        return 0U;
    }
    if ((g_tick_ms - timer->start_tick) >= timer->duration_ms) {
        timer->active = 0U; /* consume: reports expired only once */
        return 1U;
    }
    return 0U;
}

uint8_t NonBlockingDelay_IsRunning(NonBlockingDelay_t *timer) {
    if (!timer->active) {
        return 0U;
    }
    if ((g_tick_ms - timer->start_tick) >= timer->duration_ms) {
        return 0U; /* elapsed but not yet consumed by IsExpired() */
    }
    return 1U;
}

void NonBlockingDelay_Stop(NonBlockingDelay_t *timer) {
    timer->active = 0U;
}

static inline uint16_t PercentToCCR(uint8_t percent) {
    if (percent > 100) percent = 100;
    return (uint16_t)(((uint32_t)percent * (timer_arr + 1)) / 100);
}

static void Write_Pin_Duty(PWM_Pin_t pin, uint16_t ccr_val) {
    switch (pin) {
        case PIN_PA6_CH1: TIM3->CCR1 = ccr_val; break;
        case PIN_PA7_CH2: TIM3->CCR2 = ccr_val; break;
        case PIN_PB0_CH3: TIM3->CCR3 = ccr_val; break;
        case PIN_PB1_CH4: TIM3->CCR4 = ccr_val; break;
    }
}

/* Minimal Cortex-M4 SysTick register map */
#define SYSTICK_BASE_ADDR 0xE000E010UL

typedef struct {
    volatile uint32_t CTRL;
    volatile uint32_t LOAD;
    volatile uint32_t VAL;
    volatile uint32_t CALIB;
} SysTick_RegDef_t;

#define SYSTICK ((SysTick_RegDef_t *)SYSTICK_BASE_ADDR)

#define SYSTICK_CTRL_ENABLE    (1U << 0)
#define SYSTICK_CTRL_TICKINT   (1U << 1)
#define SYSTICK_CTRL_CLKSOURCE (1U << 2)

void SoftStart_SysTick_Init(uint32_t cpu_freq_hz) {
    uint32_t reload_ticks = (cpu_freq_hz / 1000U) - 1U;

    SYSTICK->CTRL = 0;
    SYSTICK->LOAD = reload_ticks;
    SYSTICK->VAL  = 0;
    SYSTICK->CTRL = SYSTICK_CTRL_ENABLE | SYSTICK_CTRL_TICKINT | SYSTICK_CTRL_CLKSOURCE;
}

void SoftStart_SetFreqDeadTime(uint32_t SF, uint32_t dt) {
    if (SF > 0) {
        active_frequency_hz = SF;
        timer_arr = (uint16_t)((MCU_CLOCK_FREQ_HZ / active_frequency_hz) - 1U);
        TIM3->ARR = timer_arr;
    }
    active_deadtime_ns = dt;
}

void SoftStart_PWM_Init(Inverter_PinMap_t pin_config) {
    active_map = pin_config;

    SoftStart_SetFreqDeadTime(active_frequency_hz, active_deadtime_ns);

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN;
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;

    GPIOA->MODER &= ~((3U << (6 * 2)) | (3U << (7 * 2)));
    GPIOA->MODER |=  ((2U << (6 * 2)) | (2U << (7 * 2)));
    GPIOA->AFR[0] &= ~((0xFU << (6 * 4)) | (0xFU << (7 * 4)));
    GPIOA->AFR[0] |=  ((2U   << (6 * 4)) | (2U   << (7 * 4)));

    GPIOB->MODER &= ~((3U << (0 * 2)) | (3U << (1 * 2)));
    GPIOB->MODER |=  ((2U << (0 * 2)) | (2U << (1 * 2)));
    GPIOB->AFR[0] &= ~((0xFU << (0 * 4)) | (0xFU << (1 * 4)));
    GPIOB->AFR[0] |=  ((2U   << (0 * 4)) | (2U   << (1 * 4)));

    TIM3->PSC = 0;
    TIM3->CCMR1 |= (6U << 4) | (1U << 3) | (6U << 12) | (1U << 11);
    TIM3->CCMR2 |= (6U << 4) | (1U << 3) | (6U << 12) | (1U << 11);

    TIM3->CCR1 = 0; TIM3->CCR2 = 0; TIM3->CCR3 = 0; TIM3->CCR4 = 0;
    TIM3->CCER |= (1U << 0) | (1U << 4) | (1U << 8) | (1U << 12);

    TIM3->EGR |= (1U << 0);
    TIM3->CR1 |= (1U << 0);
}

static void SoftStart_SetMOSFET_Duty(uint8_t duty_M1, uint8_t duty_M2, uint8_t duty_M3, uint8_t duty_M4) {
    if (duty_M1 > 0 || duty_M4 > 0) {
        Write_Pin_Duty(active_map.M2_Pin, 0);
        Write_Pin_Duty(active_map.M3_Pin, 0);
        Write_Pin_Duty(active_map.M1_Pin, PercentToCCR(duty_M1));
        Write_Pin_Duty(active_map.M4_Pin, PercentToCCR(duty_M4));
    }
    else if (duty_M2 > 0 || duty_M3 > 0) {
        Write_Pin_Duty(active_map.M1_Pin, 0);
        Write_Pin_Duty(active_map.M4_Pin, 0);
        Write_Pin_Duty(active_map.M2_Pin, PercentToCCR(duty_M2));
        Write_Pin_Duty(active_map.M3_Pin, PercentToCCR(duty_M3));
    }
    else {
        Write_Pin_Duty(active_map.M1_Pin, 0);
        Write_Pin_Duty(active_map.M2_Pin, 0);
        Write_Pin_Duty(active_map.M3_Pin, 0);
        Write_Pin_Duty(active_map.M4_Pin, 0);
    }
}

void SoftStart_Inverter_Begin(uint32_t ramp_duration_sec) {
    uint8_t steps = SOFTSTART_RAMP_END_PCT - SOFTSTART_RAMP_START_PCT;
    step_delay_ms = (ramp_duration_sec * 1000U) / steps;

    SoftStart_SetMOSFET_Duty(SOFTSTART_RAMP_START_PCT, 0, 0, SOFTSTART_RAMP_START_PCT);
    current_pct        = SOFTSTART_RAMP_START_PCT;
    current_state       = SS_STATE_START_HOLD;
    state_tick_target   = g_tick_ms + 1000U;
}

void SoftStop_Inverter_Begin(uint32_t ramp_duration_sec) {
    uint8_t steps = SOFTSTART_RAMP_FINAL_PCT - SOFTSTART_RAMP_START_PCT;
    step_delay_ms = (ramp_duration_sec * 1000U) / (steps * 2U);

    current_pct        = SOFTSTART_RAMP_FINAL_PCT;
    current_state       = SS_STATE_STOP_RAMP_PAIR23_DOWN;
    state_tick_target   = g_tick_ms;
}

void EmergencyStop_Inverter_Execute(void) {
    TIM3->CCR1 = 0;
    TIM3->CCR2 = 0;
    TIM3->CCR3 = 0;
    TIM3->CCR4 = 0;
    current_state = SS_STATE_ESTOP;
}

SoftStart_State_t SoftStart_GetState(void) {
    return current_state;
}

void SoftStart_Process(void) {
    switch (current_state) {

    case SS_STATE_IDLE:
    case SS_STATE_COMPLETE:
    case SS_STATE_STOPPED:
    case SS_STATE_ESTOP:
        break;

    case SS_STATE_START_HOLD:
        if (g_tick_ms >= state_tick_target) {
            current_pct        = SOFTSTART_RAMP_START_PCT + 1;
            current_state       = SS_STATE_RAMP_PAIR14_UP;
            state_tick_target   = g_tick_ms + step_delay_ms;
        }
        break;

    case SS_STATE_RAMP_PAIR14_UP:
        if (g_tick_ms >= state_tick_target) {
            SoftStart_SetMOSFET_Duty((uint8_t)current_pct, 0, 0, (uint8_t)current_pct);
            if (current_pct >= (int16_t)SOFTSTART_RAMP_END_PCT) {
                current_state       = SS_STATE_HOLD_PAIR14;
                state_tick_target   = g_tick_ms + (SOFTSTART_HOLD_TIME_SEC * 1000U);
            } else {
                current_pct++;
                state_tick_target = g_tick_ms + step_delay_ms;
            }
        }
        break;

    case SS_STATE_HOLD_PAIR14:
        if (g_tick_ms >= state_tick_target) {
            SoftStart_SetMOSFET_Duty(SOFTSTART_RAMP_FINAL_PCT, 0, 0, SOFTSTART_RAMP_FINAL_PCT);
            current_state       = SS_STATE_START_HOLD_PAIR23;
            state_tick_target   = g_tick_ms + 1000U;
        }
        break;

    case SS_STATE_START_HOLD_PAIR23:
        if (g_tick_ms >= state_tick_target) {
            SoftStart_SetMOSFET_Duty(0, SOFTSTART_RAMP_START_PCT, SOFTSTART_RAMP_START_PCT, 0);
            current_pct        = SOFTSTART_RAMP_START_PCT + 1;
            current_state       = SS_STATE_RAMP_PAIR23_UP;
            state_tick_target   = g_tick_ms + step_delay_ms;
        }
        break;

    case SS_STATE_RAMP_PAIR23_UP:
        if (g_tick_ms >= state_tick_target) {
            SoftStart_SetMOSFET_Duty(0, (uint8_t)current_pct, (uint8_t)current_pct, 0);
            if (current_pct >= (int16_t)SOFTSTART_RAMP_END_PCT) {
                current_state       = SS_STATE_HOLD_PAIR23;
                state_tick_target   = g_tick_ms + (SOFTSTART_HOLD_TIME_SEC * 1000U);
            } else {
                current_pct++;
                state_tick_target = g_tick_ms + step_delay_ms;
            }
        }
        break;

    case SS_STATE_HOLD_PAIR23:
        if (g_tick_ms >= state_tick_target) {
            SoftStart_SetMOSFET_Duty(0, SOFTSTART_RAMP_FINAL_PCT, SOFTSTART_RAMP_FINAL_PCT, 0);
            current_state = SS_STATE_COMPLETE;
        }
        break;

    case SS_STATE_STOP_RAMP_PAIR23_DOWN:
        if (g_tick_ms >= state_tick_target) {
            SoftStart_SetMOSFET_Duty(0, (uint8_t)current_pct, (uint8_t)current_pct, 0);
            if (current_pct <= (int16_t)SOFTSTART_RAMP_START_PCT) {
                SoftStart_SetMOSFET_Duty(0, 0, 0, 0);
                current_state       = SS_STATE_STOP_GAP;
                state_tick_target   = g_tick_ms + 100U;
            } else {
                current_pct--;
                state_tick_target = g_tick_ms + step_delay_ms;
            }
        }
        break;

    case SS_STATE_STOP_GAP:
        if (g_tick_ms >= state_tick_target) {
            current_pct        = SOFTSTART_RAMP_FINAL_PCT;
            current_state       = SS_STATE_STOP_RAMP_PAIR14_DOWN;
            state_tick_target   = g_tick_ms + step_delay_ms;
        }
        break;

    case SS_STATE_STOP_RAMP_PAIR14_DOWN:
        if (g_tick_ms >= state_tick_target) {
            SoftStart_SetMOSFET_Duty((uint8_t)current_pct, 0, 0, (uint8_t)current_pct);
            if (current_pct <= (int16_t)SOFTSTART_RAMP_START_PCT) {
                SoftStart_SetMOSFET_Duty(0, 0, 0, 0);
                current_state = SS_STATE_STOPPED;
            } else {
                current_pct--;
                state_tick_target = g_tick_ms + step_delay_ms;
            }
        }
        break;

    default:
        break;
    }
}
