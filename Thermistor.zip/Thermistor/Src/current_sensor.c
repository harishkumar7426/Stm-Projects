#include "current_sensor.h"
#include "adc.h"

/* =========================================================
 * 1. INITIALIZATION
 * ========================================================= */
void CurrentSensor_Init(void) {
    ADC1_IN1_Init();
}

/* =========================================================
 * 2. SELF TEST
 * ========================================================= */
uint8_t CurrentSensor_Test(void) {
    CurrentData_t i_data = CurrentSensor_Read();
    if (i_data.raw_adc > 4095) return 0;
    return 1;
}

/* =========================================================
 * 3. READ
 * ========================================================= */
CurrentData_t CurrentSensor_Read(void) {
    CurrentData_t i_data;
    i_data.raw_adc = ADC1_Read_IN1();
    i_data.iin_mv = (i_data.raw_adc * 3300) / 4095;
    i_data.iout_deci = (i_data.raw_adc * 1000) / 4095;
    return i_data;
}

/* =========================================================
 * 4. INTERRUPT CONTROL
 * ========================================================= */
void CurrentSensor_Init_IT(void) {
    ADC1_IT_Init();
}

uint8_t CurrentSensor_DataReady_IT(void) {
    return ADC1_IT_DataReady(1);
}

/* =========================================================
 * 5. INTERRUPT HANDLER
 * (handled centrally in adc.c -> ADC_IRQHandler;
 *  this wrapper just reads the latest IT-scanned value)
 * ========================================================= */
CurrentData_t CurrentSensor_Read_IT(void) {
    CurrentData_t i_data;
    i_data.raw_adc = ADC1_IT_GetValue(1);
    i_data.iin_mv = (i_data.raw_adc * 3300) / 4095;
    i_data.iout_deci = (i_data.raw_adc * 1000) / 4095;
    return i_data;
}
