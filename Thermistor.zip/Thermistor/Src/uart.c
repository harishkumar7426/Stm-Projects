#include "uart.h"

/* =========================================================
 * 1. INITIALIZATION
 * ========================================================= */
void USART1_Init(void) {
    RCC->APB2ENR |= (1U << 4);
    USART1->BRR = 0x8B; // 115200 baud @ 16 MHz HSI
    USART1->CR1 |= USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

/* =========================================================
 * 2. SELF TEST
 * ========================================================= */
uint8_t USART1_Test(void) {
    if (!(USART1->CR1 & USART_CR1_UE)) return 0;   // Not enabled -> fail
    if (!(USART1->SR & USART_SR_TXE)) return 0;     // Should be idle-ready -> fail
    return 1;                                          // pass
}

/* =========================================================
 * 3. READ / WRITE
 * ========================================================= */
void USART1_WriteChar(char c) {
    while (!(USART1->SR & USART_SR_TXE));
    USART1->DR = (c & 0xFF);
}

void USART1_WriteString(const char *str) {
    while (*str) {
        USART1_WriteChar(*str++);
    }
}

char USART1_ReadChar_Timeout(uint32_t timeout_loops) {
    while (timeout_loops--) {
        if (USART1->SR & USART_SR_RXNE) {
            return (char)(USART1->DR & 0xFF);
        }
    }
    return 0;
}

void USART1_WaitTransmissionComplete(void) {
    while (!(USART1->SR & USART_SR_TC));
}

/* =========================================================
 * 4. INTERRUPT CONTROL
 * ========================================================= */
#define UART_RX_BUF_SIZE 64

static volatile char    rx_buffer[UART_RX_BUF_SIZE];
static volatile uint8_t rx_head = 0;
static volatile uint8_t rx_tail = 0;

void USART1_Init_IT(void) {
    RCC->APB2ENR |= (1U << 4);
    USART1->BRR = 0x8B;
    USART1->CR1 |= USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
    USART1->CR1 |= USART_CR1_RXNEIE; // Enable RX-not-empty interrupt

    NVIC_EnableIRQ(USART1_IRQn);
}

uint8_t USART1_RxAvailable(void) {
    return (rx_head != rx_tail);
}

char USART1_RxRead(void) {
    if (rx_head == rx_tail) return 0;
    char c = rx_buffer[rx_tail];
    rx_tail = (uint8_t)((rx_tail + 1) % UART_RX_BUF_SIZE);
    return c;
}

/* =========================================================
 * 5. INTERRUPT HANDLER
 * ========================================================= */
void USART1_IRQHandler(void) {
    if (USART1->SR & USART_SR_RXNE) {
        char c = (char)(USART1->DR & 0xFF); // reading DR clears RXNE
        uint8_t next_head = (uint8_t)((rx_head + 1) % UART_RX_BUF_SIZE);
        if (next_head != rx_tail) { // drop byte if buffer full
            rx_buffer[rx_head] = c;
            rx_head = next_head;
        }
    }
}
