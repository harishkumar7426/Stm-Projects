#include "adc.h"
#include "stm32f446xx_registers.h"

volatile uint16_t adc_it_values[3] = {0};
volatile uint8_t  adc_it_ready[3]  = {0};
volatile uint8_t  adc_it_current_channel = 0;

void ADC1_Init(void) {
    // 1. Clock Enable: GPIOA and ADC1
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

    // 2. Analog Mode on PA0, PA1, PA2
    GPIOA->MODER |= (3U << (0 * 2)) | (3U << (1 * 2)) | (3U << (2 * 2));

    // 3. Power ON ADC1
    ADC1->CR2 |= ADC_CR2_ADON;
}

void ADC1_IT_Init(void) {
    ADC1_Init();

    // Enable EOC (End Of Conversion) interrupt
    ADC1->CR1 |= ADC_CR1_EOCIE;

    // Enable ADC Interrupt line in Cortex-M4 NVIC
    NVIC_EnableIRQ(ADC_IRQn);
}

uint16_t ADC1_ReadChannel(uint8_t channel) {
    ADC1->SQR3 &= ~(0x1FU);
    ADC1->SQR3 |= (channel & 0x1FU);

    ADC1->CR2 |= ADC_CR2_SWSTART;
    while (!(ADC1->SR & ADC_SR_EOC));

    return (uint16_t)ADC1->DR;
}

// Global ADC IRQ Handler
void ADC1_2_IRQHandler(void) {
    if (ADC1->SR & ADC_SR_EOC) {
        adc_it_values[adc_it_current_channel] = (uint16_t)ADC1->DR;
        adc_it_ready[adc_it_current_channel] = 1;

        adc_it_current_channel++;
        if (adc_it_current_channel > 2) {
            adc_it_current_channel = 0;
        }

        ADC1->SQR3 &= ~(0x1FU);
        ADC1->SQR3 |= (adc_it_current_channel & 0x1FU);
        ADC1->CR2  |= ADC_CR2_SWSTART;
    }
}
