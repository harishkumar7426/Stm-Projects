#include "nb_delay.h"
/**
 * @brief Stateless interval timer check.
 */
bool NB_Delay_Elapsed(uint32_t *last_tick, uint32_t interval_ms) {
    uint32_t current_tick = Get_System_Ticks();

    if ((current_tick - *last_tick) >= interval_ms) {
        *last_tick = current_tick;
        return true;
    }
    return false;
}

/**
 * @brief Starts or restarts a non-blocking timer object.
 */
void NB_Timer_Start(NB_Timer_t *timer, uint32_t duration_ms) {
    if (timer == NULL) return;

    timer->start_tick  = Get_System_Ticks();
    timer->duration_ms = duration_ms;
    timer->is_running  = true;
}

/**
 * @brief Checks if a timer object has expired (One-Shot).
 */
bool NB_Timer_IsExpired(NB_Timer_t *timer) {
    if (timer == NULL || !timer->is_running) {
        return false;
    }

    uint32_t current_tick = Get_System_Ticks();
    if ((current_tick - timer->start_tick) >= timer->duration_ms) {
        timer->is_running = false;
        return true;
    }
    return false;
}

/**
 * @brief Manually stops an active timer.
 */
void NB_Timer_Stop(NB_Timer_t *timer) {
    if (timer != NULL) {
        timer->is_running = false;
    }
}

/**
 * @brief Returns active status of the timer.
 */
bool NB_Timer_IsRunning(const NB_Timer_t *timer) {
    if (timer == NULL) {
        return false;
    }
    return timer->is_running;
}
