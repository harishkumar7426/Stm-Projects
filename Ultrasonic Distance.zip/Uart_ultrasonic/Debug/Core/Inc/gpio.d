Core/Inc/gpio.o: ../Core/Inc/gpio.c ../Core/Inc/registers.h \
 ../Core/Inc/gpio.h
../Core/Inc/registers.h:
../Core/Inc/gpio.h:
