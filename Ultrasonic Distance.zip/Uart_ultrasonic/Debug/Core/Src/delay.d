Core/Src/delay.o: ../Core/Src/delay.c ../Core/Inc/delay.h \
 ../Core/Inc/timer.h ../Core/Inc/registers.h
../Core/Inc/delay.h:
../Core/Inc/timer.h:
../Core/Inc/registers.h:
