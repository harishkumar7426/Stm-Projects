Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/gpio.h ../Core/Inc/uart.h \
 ../Core/Inc/timer.h ../Core/Inc/registers.h ../Core/Inc/delay.h \
 ../Core/Inc/ultrasonic.h
../Core/Inc/gpio.h:
../Core/Inc/uart.h:
../Core/Inc/timer.h:
../Core/Inc/registers.h:
../Core/Inc/delay.h:
../Core/Inc/ultrasonic.h:
