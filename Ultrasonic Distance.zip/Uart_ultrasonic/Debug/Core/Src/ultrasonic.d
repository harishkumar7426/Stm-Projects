Core/Src/ultrasonic.o: ../Core/Src/ultrasonic.c ../Core/Inc/gpio.h \
 ../Core/Inc/delay.h ../Core/Inc/timer.h ../Core/Inc/registers.h
../Core/Inc/gpio.h:
../Core/Inc/delay.h:
../Core/Inc/timer.h:
../Core/Inc/registers.h:
