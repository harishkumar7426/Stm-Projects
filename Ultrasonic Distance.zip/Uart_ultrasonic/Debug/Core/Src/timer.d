Core/Src/timer.o: ../Core/Src/timer.c ../Core/Inc/registers.h \
 ../Core/Inc/timer.h ../Core/Inc/registers.h
../Core/Inc/registers.h:
../Core/Inc/timer.h:
../Core/Inc/registers.h:
