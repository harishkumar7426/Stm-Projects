Core/Src/uart.o: ../Core/Src/uart.c ../Core/Inc/registers.h \
 ../Core/Inc/uart.h
../Core/Inc/registers.h:
../Core/Inc/uart.h:
