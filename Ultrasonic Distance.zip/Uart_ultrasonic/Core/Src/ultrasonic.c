#include "gpio.h"
#include "delay.h"
#include "timer.h"

unsigned int Ultrasonic_Read(void)
{
    unsigned int time;

    /* Trigger Pulse */

    Trigger_Low();
    Delay_us(2);

    Trigger_High();
    Delay_us(10);

    Trigger_Low();

    /* Wait for Echo HIGH */

    while(!Echo_Read());

    Timer_Reset();

    /* Measure Echo Pulse */

    while(Echo_Read());

    time = Timer_Count();

    /* Convert to cm */

    return (time / 58);
}
