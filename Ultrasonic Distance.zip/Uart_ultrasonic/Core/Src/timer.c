#include "registers.h"
#include "timer.h"

void TIM2_Init(void)
{
    /* Enable TIM2 Clock */

    RCC_APB1ENR |= (1<<0);

    /* Stop Timer */

    TIM2_CR1 &= ~(1<<0);

    /* Prescaler */

    /* 16MHz / (15+1) = 1MHz */

    TIM2_PSC = 15;

    /* Auto Reload */

    TIM2_ARR = 0xFFFFFFFF;

    /* Update Registers */

    TIM2_EGR |= (1<<0);

    /* Clear Counter */

    TIM2_CNT = 0;

    /* Start Timer */

    TIM2_CR1 |= (1<<0);
}

void Timer_Reset(void)
{
    TIM2_CNT = 0;
}

uint32_t Timer_Count(void)
{
    return TIM2_CNT;
}
