#include "gpio.h"
#include "uart.h"
#include "timer.h"
#include "delay.h"
#include "ultrasonic.h"

int main(void)
{
    unsigned int distance;

    GPIO_Init();

    UART2_Init();

    TIM2_Init();

    while(1)
    {
        distance = Ultrasonic_Read();

        UART2_SendString("Distance : ");

        UART2_SendNumber(distance);

        UART2_SendString(" cm\r\n");

        Delay_ms(500);
    }
}
