#include "delay.h"
#include "timer.h"

void Delay_us(unsigned int us)
{
    Timer_Reset();

    while(Timer_Count() < us);
}

void Delay_ms(unsigned int ms)
{
    while(ms--)
    {
        Delay_us(1000);
    }
}
