#include "registers.h"
#include "gpio.h"

void GPIO_Init(void)
{
    /* Enable GPIOA Clock */

    RCC_AHB1ENR |= (1<<0);

    /* PA0 OUTPUT */

    GPIOA_MODER &= ~(3<<(0*2));
    GPIOA_MODER |=  (1<<(0*2));

    /* PA1 INPUT */

    GPIOA_MODER &= ~(3<<(1*2));

    /* PA2 PA3 Alternate Function */

    GPIOA_MODER &= ~(3<<(2*2));
    GPIOA_MODER |=  (2<<(2*2));

    GPIOA_MODER &= ~(3<<(3*2));
    GPIOA_MODER |=  (2<<(3*2));

    /* AF7 USART2 */

    GPIOA_AFRL &= ~(0xF<<(2*4));
    GPIOA_AFRL |=  (7<<(2*4));

    GPIOA_AFRL &= ~(0xF<<(3*4));
    GPIOA_AFRL |=  (7<<(3*4));
}

void Trigger_High(void)
{
    GPIOA_BSRR=(1<<0);
}

void Trigger_Low(void)
{
    GPIOA_BSRR=(1<<(0+16));
}

int Echo_Read(void)
{
    return (GPIOA_IDR&(1<<1));
}
