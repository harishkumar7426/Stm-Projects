#ifndef REGISTERS_H
#define REGISTERS_H

typedef unsigned int uint32_t;

/*==================================================
                    RCC
==================================================*/

#define RCC_BASE        0x40023800UL

#define RCC_CR          (*(volatile uint32_t *)(RCC_BASE+0x00))
#define RCC_PLLCFGR     (*(volatile uint32_t *)(RCC_BASE+0x04))
#define RCC_CFGR        (*(volatile uint32_t *)(RCC_BASE+0x08))

#define RCC_AHB1ENR     (*(volatile uint32_t *)(RCC_BASE+0x30))
#define RCC_APB1ENR     (*(volatile uint32_t *)(RCC_BASE+0x40))
#define RCC_APB2ENR     (*(volatile uint32_t *)(RCC_BASE+0x44))

/*==================================================
                    GPIOA
==================================================*/

#define GPIOA_BASE      0x40020000UL

#define GPIOA_MODER     (*(volatile uint32_t *)(GPIOA_BASE+0x00))
#define GPIOA_OTYPER    (*(volatile uint32_t *)(GPIOA_BASE+0x04))
#define GPIOA_OSPEEDR   (*(volatile uint32_t *)(GPIOA_BASE+0x08))
#define GPIOA_PUPDR     (*(volatile uint32_t *)(GPIOA_BASE+0x0C))
#define GPIOA_IDR       (*(volatile uint32_t *)(GPIOA_BASE+0x10))
#define GPIOA_ODR       (*(volatile uint32_t *)(GPIOA_BASE+0x14))
#define GPIOA_BSRR      (*(volatile uint32_t *)(GPIOA_BASE+0x18))
#define GPIOA_AFRL      (*(volatile uint32_t *)(GPIOA_BASE+0x20))
#define GPIOA_AFRH      (*(volatile uint32_t *)(GPIOA_BASE+0x24))

/*==================================================
                    USART2
==================================================*/

#define USART2_BASE     0x40004400UL

#define USART2_SR       (*(volatile uint32_t *)(USART2_BASE+0x00))
#define USART2_DR       (*(volatile uint32_t *)(USART2_BASE+0x04))
#define USART2_BRR      (*(volatile uint32_t *)(USART2_BASE+0x08))
#define USART2_CR1      (*(volatile uint32_t *)(USART2_BASE+0x0C))
#define USART2_CR2      (*(volatile uint32_t *)(USART2_BASE+0x10))
#define USART2_CR3      (*(volatile uint32_t *)(USART2_BASE+0x14))

/*==================================================
                    TIM2
==================================================*/

#define TIM2_BASE       0x40000000UL

#define TIM2_CR1        (*(volatile uint32_t *)(TIM2_BASE+0x00))
#define TIM2_CR2        (*(volatile uint32_t *)(TIM2_BASE+0x04))
#define TIM2_SMCR       (*(volatile uint32_t *)(TIM2_BASE+0x08))
#define TIM2_DIER       (*(volatile uint32_t *)(TIM2_BASE+0x0C))
#define TIM2_SR         (*(volatile uint32_t *)(TIM2_BASE+0x10))
#define TIM2_EGR        (*(volatile uint32_t *)(TIM2_BASE+0x14))
#define TIM2_CCMR1      (*(volatile uint32_t *)(TIM2_BASE+0x18))
#define TIM2_CCER       (*(volatile uint32_t *)(TIM2_BASE+0x20))
#define TIM2_CNT        (*(volatile uint32_t *)(TIM2_BASE+0x24))
#define TIM2_PSC        (*(volatile uint32_t *)(TIM2_BASE+0x28))
#define TIM2_ARR        (*(volatile uint32_t *)(TIM2_BASE+0x2C))
#define TIM2_CCR1       (*(volatile uint32_t *)(TIM2_BASE+0x34))

#endif
