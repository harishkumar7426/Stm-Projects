#ifndef ULTRASONIC_H
#define ULTRASONIC_H

unsigned int Ultrasonic_Read(void);

#endif
