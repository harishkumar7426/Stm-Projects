#ifndef GPIO_H
#define GPIO_H

void GPIO_Init(void);

void Trigger_High(void);

void Trigger_Low(void);

int Echo_Read(void);

#endif
