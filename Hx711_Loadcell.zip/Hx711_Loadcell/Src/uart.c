#include "uart.h"

#define UART_RX_BUF_SIZE 64

static volatile uint8_t  uart_rx_buf[UART_RX_BUF_SIZE];
static volatile uint16_t uart_rx_head = 0; /* next write index  */
static volatile uint16_t uart_rx_tail = 0; /* next read index   */


#define NVIC_ISER1 (*(volatile uint32_t *)0xE000E104UL)
#define USART2_IRQ_BIT (1U << 6)

void USART2_TX_Init(void)
{
    /* 1. Enable Clock for GPIOA and USART2 */
    RCC_AHB1ENR |= (1 << 0);  /* GPIOA clock enable */
    RCC_APB1ENR |= (1 << 17); /* USART2 clock enable */

    /* 2. Configure PA2 (TX) and PA3 (RX) for Alternate Function Mode (AF7) */
    GPIOA_MODER &= ~((3 << 4) | (3 << 6));
    GPIOA_MODER |= ((2 << 4) | (2 << 6)); /* AF Mode */

    GPIOA_AFRL &= ~((0xF << 8) | (0xF << 12));
    GPIOA_AFRL |= ((0x7 << 8) | (0x7 << 12)); /* AF7 for USART2 */

    /* 3. Configure Baudrate: 115200 @ 16MHz */
    USART2_BRR = 0x008B;

    /* 4. Enable Receiver, Transmitter, and USART module */
    USART2_CR1 |= (1 << 2) | (1 << 3) | (1 << 13);

    /* 5. Enable RXNE interrupt so bytes are captured in the ISR
     *    instead of being polled (and potentially lost). */
    USART2_CR1 |= (1 << 5); /* RXNEIE */

    /* 6. Enable USART2 interrupt line in NVIC */
    NVIC_ISER1 |= USART2_IRQ_BIT;
}

/* Interrupt handler: fires whenever RXNE is set. Reading USART2_DR
 * clears RXNE automatically. Keep this short and non-blocking. */
void USART2_IRQHandler(void)
{
    if (USART2_SR & (1 << 5)) /* RXNE */
    {
        uint8_t byte = (uint8_t)(USART2_DR & 0xFF);
        uint16_t next_head = (uart_rx_head + 1) % UART_RX_BUF_SIZE;

        if (next_head != uart_rx_tail) {
            uart_rx_buf[uart_rx_head] = byte;
            uart_rx_head = next_head;
        }
        /* else: buffer full, byte is dropped (extremely unlikely at
         * 115200 baud with a 64-byte buffer being drained every loop) */
    }
}

void USART2_SendChar(char c)
{
    while (!(USART2_SR & (1 << 7))); /* Wait for TXE */
    USART2_DR = (c & 0xFF);
}

void USART2_SendString(const char *str)
{
    while (*str) {
        USART2_SendChar(*str++);
    }
}

void USART2_SendNumber(long num)
{
    char buf[12];
    int i = 0;

    if (num == 0) {
        USART2_SendChar('0');
        return;
    }

    if (num < 0) {
        USART2_SendChar('-');
        num = -num;
    }

    while (num > 0) {
        buf[i++] = (num % 10) + '0';
        num /= 10;
    }

    while (i > 0) {
        USART2_SendChar(buf[--i]);
    }
}

void USART2_SendHexByte(uint8_t byte)
{
    const char hex_chars[] = "0123456789ABCDEF";
    USART2_SendChar(hex_chars[(byte >> 4) & 0x0F]);
    USART2_SendChar(hex_chars[byte & 0x0F]);
}

void USART2_SendHex16(uint16_t val)
{
    USART2_SendHexByte((uint8_t)((val >> 8) & 0xFF));
    USART2_SendHexByte((uint8_t)(val & 0xFF));
}

/* Prints a centigram value (grams * 100) as "XXX.XX", e.g. 20050 -> "200.50" */
void USART2_SendWeight(long weight_centi)
{
    if (weight_centi < 0) {
        USART2_SendChar('-');
        weight_centi = -weight_centi;
    }

    long whole = weight_centi / 100;
    long frac  = weight_centi % 100;

    USART2_SendNumber(whole);
    USART2_SendChar('.');

    /* Always print exactly 2 fractional digits (zero-padded) */
    if (frac < 10) {
        USART2_SendChar('0');
    }
    USART2_SendNumber(frac);
}

/* Now reads from the ring buffer (filled by the ISR) instead of
 * polling USART2_DR directly. Still blocks until a byte is available,
 * so every other function that calls this keeps working unchanged. */
char USART2_ReadChar(void)
{
    while (uart_rx_head == uart_rx_tail); /* wait for ISR to deliver a byte */

    char c = (char)uart_rx_buf[uart_rx_tail];
    uart_rx_tail = (uart_rx_tail + 1) % UART_RX_BUF_SIZE;
    return c;
}

void USART2_Flush(void)
{
    /* Drain the ring buffer instead of the hardware register */
    uart_rx_tail = uart_rx_head;
}

/* Check if any byte is waiting in the ring buffer */
uint8_t USART2_IsDataAvailable(void)
{
    return (uart_rx_head != uart_rx_tail) ? 1 : 0;
}

/* Safe integer reader with validation: returns 0 on non-digit characters */
uint8_t USART2_ReadNumber_Safe(int32_t *out_num)
{
    int32_t val = 0;
    int digits_count = 0;

    while (1) {
        char c = USART2_ReadChar();

        /* Enter or Line Feed terminates input */
        if (c == '\r' || c == '\n') {
            USART2_SendString("\r\n");
            break;
        }

        /* Echo valid digit key back to screen */
        if (c >= '0' && c <= '9') {
            USART2_SendChar(c);
            val = (val * 10) + (c - '0');
            digits_count++;
        }
        /* Ignore spaces */
        else if (c == ' ') {
            continue;
        }
        /* Invalid non-integer character detected */
        else {
            USART2_SendString("\r\nERR: Invalid character detected! Integers only.\r\n");
            USART2_Flush(); /* Clear remaining junk from RX buffer */
            return 0;       /* Abort command safely */
        }
    }

    if (digits_count == 0) {
        USART2_SendString("ERR: No weight entered!\r\n");
        return 0;
    }

    *out_num = val;
    return 1; /* Valid number */
}

/* Reads an integer or decimal number (e.g. "205", "205.5", "205.55")
 * and returns it as a fixed-point centi-value: value * 100.
 * "205.5" -> 20550, "205" -> 20500. Same input rules as
 * USART2_ReadNumber_Safe() (echoes digits, Enter terminates, invalid
 * character aborts and returns 0), plus a single '.' is now allowed.
 * Only the first 2 digits after the decimal point are kept; further
 * digits are echoed but ignored numerically. */
uint8_t USART2_ReadDecimal_Safe(int32_t *out_centi)
{
    int32_t whole = 0;
    int32_t frac = 0;
    int digits_count = 0;
    uint8_t seen_dot = 0;
    int frac_digits = 0;

    while (1) {
        char c = USART2_ReadChar();

        /* Enter or Line Feed terminates input */
        if (c == '\r' || c == '\n') {
            USART2_SendString("\r\n");
            break;
        }

        if (c >= '0' && c <= '9') {
            USART2_SendChar(c);
            if (!seen_dot) {
                whole = (whole * 10) + (c - '0');
            } else if (frac_digits < 2) {
                frac = (frac * 10) + (c - '0');
                frac_digits++;
            }
            /* else: 3rd+ fractional digit typed - echoed above but
             * not counted, so precision stays fixed at 2 decimals */
            digits_count++;
        }
        else if (c == '.' && !seen_dot) {
            USART2_SendChar(c);
            seen_dot = 1;
        }
        /* Ignore spaces */
        else if (c == ' ') {
            continue;
        }
        /* Invalid character detected */
        else {
            USART2_SendString("\r\nERR: Invalid character detected! Numbers only (decimals allowed).\r\n");
            USART2_Flush();
            return 0;
        }
    }

    if (digits_count == 0) {
        USART2_SendString("ERR: No weight entered!\r\n");
        return 0;
    }

    /* Pad fractional part out to exactly 2 digits, e.g. "5" -> 50 centi */
    while (frac_digits < 2) {
        frac *= 10;
        frac_digits++;
    }

    *out_centi = (whole * 100) + frac;
    return 1;
}

/* Checks if CMD_STOP (0x00) arrived during non-blocking loops.
 * Now reads from the ring buffer (via the head/tail indices) so it
 * can't race with / lose bytes to the ISR. */
uint8_t USART2_CheckForStopCommand(void)
{
    if (USART2_IsDataAvailable()) {
        uint8_t rx_byte = uart_rx_buf[uart_rx_tail];
        uart_rx_tail = (uart_rx_tail + 1) % UART_RX_BUF_SIZE;

        if (rx_byte == CMD_STOP || rx_byte == 0xAA) {
            USART2_Flush();
            return 1;
        }
    }
    return 0;
}

/* 9-Byte Binary Packet Stream Receiver */
UART_Packet USART2_ReceivePacket(void)
{
    UART_Packet pkt = {0, 0, 0, 0, 0, 0};
    uint8_t raw_buf[9];

    /* 1. Synchronize to Start Byte 0xAA */
    uint8_t rx_byte;
    do {
        rx_byte = (uint8_t)USART2_ReadChar();
    } while (rx_byte != 0xAA);

    raw_buf[0] = rx_byte;

    /* 2. Read remaining 8 raw binary bytes */
    for (int i = 1; i < 9; i++) {
        raw_buf[i] = (uint8_t)USART2_ReadChar();
    }

    /* 3. Validate Stop Byte (0xFF) */
    if (raw_buf[8] == 0xFF) {
        pkt.start_marker = raw_buf[0];
        pkt.id           = (uint16_t)((raw_buf[1] << 8) | raw_buf[2]);
        pkt.command      = raw_buf[3];
        pkt.data         = ((uint32_t)raw_buf[4] << 24) |
                           ((uint32_t)raw_buf[5] << 16) |
                           ((uint32_t)raw_buf[6] << 8)  |
                           ((uint32_t)raw_buf[7]);
        pkt.stop_marker  = raw_buf[8];
        pkt.valid        = 1;
    } else {
        USART2_Flush();
        pkt.valid = 0;
    }

    return pkt;
}
