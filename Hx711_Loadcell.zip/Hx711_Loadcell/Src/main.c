#include "uart.h"
#include "hx711.h"

/* Helper function to get 1 sample while constantly checking for UART STOP packet */
static int HX711_ReadWithInterruptCheck(long *out_raw)
{
    /* Read single sample from HX711 */
    *out_raw = HX711_Read();

    /* Immediately check if UART has incoming data */
    if (USART2_IsDataAvailable()) {
        UART_Packet stop_pkt = USART2_ReceivePacket();
        if (stop_pkt.valid && stop_pkt.command == 0x00) {
            return 1; /* STOP command detected! */
        }
    }
    return 0; /* Continue monitoring */
}

int main(void)
{
    USART2_TX_Init();
    HX711_Init();

    USART2_SendString("\r\n====================================\r\n");
    USART2_SendString(" HX711 COOLTERM RAW BINARY SYSTEM \r\n");
    USART2_SendString("====================================\r\n");
    USART2_SendString("Binary Packet Frame (9 Bytes):\r\n");
    USART2_SendString(" [AA] [00] [FF] [CMD] [DATA3..0] [FF]\r\n");
    USART2_SendString(" Command Protocol:\r\n");
    USART2_SendString("  0x00 : STOP / IDLE / RESET\r\n");
    USART2_SendString("  0x01 : TARE\r\n");
    USART2_SendString("  0x02 : CALIBRATE\r\n");
    USART2_SendString("  0x03 : SINGLE MEASURE\r\n");
    USART2_SendString("  0x04 : TARGET MEASURE (uint32_t)\r\n");
    USART2_SendString("  0x05 : LIVE CONTINUOUS MONITORING\r\n");
    USART2_SendString("------------------------------------\r\n");

    HX711_CalibrationData cal;
    cal.tare = 0;
    cal.raw_diff = 1;           /* avoid divide-by-zero before real calibration */
    cal.known_weight_centi = 0; /* weight reads as 0.00 g until calibrated      */

    while(1)
    {
        USART2_SendString("\r\nWaiting for Raw Hex Packet...\r\n");

        UART_Packet pkt = USART2_ReceivePacket();

        if(!pkt.valid) {
            USART2_SendString("ERR: Frame Error (Invalid Stop Byte)!\r\n");
            USART2_Flush();
            continue;
        }

        /* Echo received command back to terminal */
        USART2_SendString("Packet Parsed -> CMD: 0x");
        USART2_SendHexByte(pkt.command);
        USART2_SendString(" | DATA Payload: ");
        USART2_SendNumber((long)pkt.data);
        USART2_SendString("\r\n");

        switch(pkt.command)
        {
            case 0x00: /* CMD 0x00: STOP / RESET / IDLE */
            execute_stop_idle:
            {
                USART2_SendString(">>> SYSTEM STOPPED / IDLE MODE ACTIVE <<<\r\n");
                USART2_SendString("Send any valid command packet to resume operation...\r\n");
                USART2_Flush();

                /* Inner blocking loop: Holds MCU in idle until next valid packet arrives */
                uint8_t stopped = 1;
                while(stopped)
                {
                    UART_Packet new_pkt = USART2_ReceivePacket();

                    if(new_pkt.valid) {
                        if(new_pkt.command != 0x00) {
                            pkt = new_pkt;
                            stopped = 0;

                            USART2_SendString("\r\n>>> SYSTEM RESUMED <<<\r\n");
                            USART2_SendString("Packet Parsed -> CMD: 0x");
                            USART2_SendHexByte(pkt.command);
                            USART2_SendString(" | DATA Payload: ");
                            USART2_SendNumber((long)pkt.data);
                            USART2_SendString("\r\n");
                        } else {
                            USART2_SendString(">>> System is already STOPPED. Send 0x01-0x05 to resume.\r\n");
                        }
                    }
                }

                /* Process the command that woke up the system */
                if(pkt.command == 0x01) {
                    USART2_SendString(">>> Executing Tare...\r\n");
                    cal.tare = HX711_Tare();
                } else if(pkt.command == 0x02) {
                    USART2_SendString(">>> Executing Calibration Routine...\r\n");
                    cal = HX711_Calibrate();
                } else if(pkt.command == 0x03) {
                    long raw = HX711_ReadAverage(5);
                    long weight = HX711_GetWeight(&cal, raw);
                    if (weight < 0) weight = 0;
                    USART2_SendString(">>> Weight Read: ");
                    USART2_SendWeight(weight);
                    USART2_SendString(" g\r\n");
                } else if(pkt.command == 0x04) {
                    uint32_t target_grams = pkt.data;
                    if(target_grams > 0) {
                        long target_centi = (long)target_grams * 100;
                        HX711_MeasureTarget(&cal, target_centi);
                    } else {
                        USART2_SendString("ERR: Target weight must be > 0g!\r\n");
                    }
                } else if(pkt.command == 0x05) {
                    goto execute_live_monitoring;
                }
                break;
            }

            case 0x01: /* CMD 0x01: TARE */
                USART2_SendString(">>> Executing Tare...\r\n");
                cal.tare = HX711_Tare();
                break;

            case 0x02: /* CMD 0x02: CALIBRATE */
                USART2_SendString(">>> Executing Calibration Routine...\r\n");
                cal = HX711_Calibrate();
                break;

            case 0x03: /* CMD 0x03: SINGLE MEASURE */
            {
                long raw = HX711_ReadAverage(5);
                long weight = HX711_GetWeight(&cal, raw);
                if (weight < 0) weight = 0;

                USART2_SendString(">>> Weight Read: ");
                USART2_SendWeight(weight);
                USART2_SendString(" g\r\n");
                break;
            }

            case 0x04: /* CMD 0x04: TARGET MEASURE */
            {
                uint32_t target_grams = pkt.data;

                if(target_grams > 0) {
                    long target_centi = (long)target_grams * 100;
                    HX711_MeasureTarget(&cal, target_centi);
                } else {
                    USART2_SendString("ERR: Target weight must be > 0g!\r\n");
                }
                break;
            }

            case 0x05: /* CMD 0x05: LIVE CONTINUOUS MONITORING */
            execute_live_monitoring:
            {
                USART2_SendString("\r\n------------------------------------\r\n");
                USART2_SendString(" Live Monitoring Started...\r\n");
                USART2_SendString(" Send CMD 0x00 to Exit\r\n");
                USART2_SendString("------------------------------------\r\n\r\n");

                uint8_t monitoring = 1;
                while(monitoring)
                {
                    long raw = 0;

                    /* Take a single fast sample instead of blocking for 3 average samples */
                    if (HX711_ReadWithInterruptCheck(&raw)) {
                        USART2_SendString(">>> Live Monitoring Stopped.\r\n");
                        goto execute_stop_idle;
                    }

                    long weight = HX711_GetWeight(&cal, raw);
                    if (weight < 0) weight = 0;

                    USART2_SendString("Live Weight: ");
                    USART2_SendWeight(weight);
                    USART2_SendString(" g\r\n");
                }
                break;
            }

            default:
                USART2_SendString("ERR: Unknown Command Code! Resetting...\r\n");
                USART2_Flush();
                break;
        }
    }
}
