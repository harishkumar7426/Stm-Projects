#include "hx711.h"
#include "uart.h"
#include "registers.h"

static void HX711_Delay(void)
{
    for(volatile int i = 0; i < 25; i++)
    {
        __asm__("nop");
    }
}

static void HX711_DelayMs(unsigned int ms)
{
    for(volatile unsigned int i = 0; i < ms; i++)
    {
        for(volatile unsigned int j = 0; j < 3200; j++)
        {
            __asm__("nop");
        }
    }
}

void HX711_Init(void)
{
    /* Enable GPIOC Clock */
    RCC_AHB1ENR |= (1 << 2);

    /* PC1 OUTPUT */
    GPIOC_MODER &= ~(3 << (2 * 1));
    GPIOC_MODER |= (1 << (2 * 1));

    /* PC0 INPUT */
    GPIOC_MODER &= ~(3 << (2 * 0));

    /* No Pull-Up / Pull-Down */
    GPIOC_PUPDR &= ~(3 << (2 * 0));

    /* SCK LOW */
    GPIOC_ODR &= ~(1 << 1);

    HX711_DelayMs(100);
}

long HX711_Read(void)
{
    unsigned long data = 0;
    unsigned long timeout = 1000000;

    /* Wait until HX711 DT pin goes LOW */
    while(GPIOC_IDR & (1 << HX711_DT_PIN))
    {
        timeout--;
        if(timeout == 0)
        {
            return 0;
        }
    }

    /* Read 24 Bits */
    for(int i = 0; i < 24; i++)
    {
        GPIOC_ODR |= (1 << HX711_SCK_PIN);
        HX711_Delay();

        data <<= 1;

        if(GPIOC_IDR & (1 << HX711_DT_PIN))
        {
            data++;
        }

        GPIOC_ODR &= ~(1 << HX711_SCK_PIN);
        HX711_Delay();
    }

    /* 25th Pulse (Gain = 128) */
    GPIOC_ODR |= (1 << HX711_SCK_PIN);
    HX711_Delay();

    GPIOC_ODR &= ~(1 << HX711_SCK_PIN);
    HX711_Delay();

    /* Sign Extend 24-bit value to standard 32-bit signed long */
    if(data & 0x800000)
    {
        data |= 0xFF000000;
    }

    return (long)data;
}

long HX711_ReadAverage(unsigned char samples)
{
    if(samples == 0) return 0;

    long sum = 0;
    for(unsigned char i = 0; i < samples; i++)
    {
        sum += HX711_Read();
        HX711_DelayMs(10);
    }

    return sum / samples;
}

long HX711_Tare(void)
{
    USART2_Flush();
    USART2_SendString("\r\nRemove all weight...\r\n");
    USART2_SendString("Calculating Tare...\r\n");

    HX711_DelayMs(1500);

    long tare = HX711_ReadAverage(30);

    USART2_SendString("Tare Value : ");
    USART2_SendNumber(tare);
    USART2_SendString("\r\n");

    return tare;
}

HX711_CalibrationData HX711_Calibrate(void)
{
    HX711_CalibrationData cal;
    cal.tare = 0;
    cal.raw_diff = 1;           /* avoid divide-by-zero before real calibration */
    cal.known_weight_centi = 0; /* weight reads as 0.00 g until calibrated      */

    USART2_SendString("\r\n==============================\r\n");
    USART2_SendString("HX711 CALIBRATION ROUTINE\r\n");
    USART2_SendString("==============================\r\n");

    /* Step 1: Tare */
    cal.tare = HX711_Tare();

    /* Step 2: Input Known Weight safely (decimals allowed, e.g. 205.5) */
    USART2_Flush();
    USART2_SendString("\r\nPlace Known Weight\r\n");
    USART2_SendString("Enter Weight in grams (decimals allowed, e.g. 205.50): ");

    int32_t knownWeightCenti = 0;

    /* Validate user input: Returns 0 if garbage/invalid chars are entered */
    if (!USART2_ReadDecimal_Safe(&knownWeightCenti) || knownWeightCenti <= 0) {
        USART2_SendString(">>> Calibration Cancelled! Resetting command...\r\n");
        return cal; /* Return back to main loop safely */
    }

    USART2_SendString("\r\nWaiting 3 Seconds...\r\n");
    HX711_DelayMs(3000);

    long raw = HX711_ReadAverage(30);

    USART2_SendString("Loaded Raw : ");
    USART2_SendNumber(raw);
    USART2_SendString("\r\n");

    long difference = raw - cal.tare;

    if(difference == 0)
    {
        difference = 1;
    }

    cal.raw_diff = difference;
    cal.known_weight_centi = knownWeightCenti;

    USART2_SendString("Calibration Completed\r\n");
    USART2_SendString("Known Weight : ");
    USART2_SendWeight(cal.known_weight_centi);
    USART2_SendString(" g\r\n");
    USART2_SendString("Raw Diff     : ");
    USART2_SendNumber(cal.raw_diff);
    USART2_SendString("\r\n");

    return cal;
}

/* Returns weight in centigrams (grams * 100). A 64-bit intermediate is
 * used so the multiply can't overflow a 32-bit long even for large
 * raw ADC deltas. */
long HX711_GetWeight(HX711_CalibrationData *cal, long raw)
{
    if(cal->raw_diff == 0)
    {
        return 0;
    }

    long diff = raw - cal->tare;

    int64_t weight_centi = ((int64_t)diff * (int64_t)cal->known_weight_centi) / cal->raw_diff;

    /* Deadband: treat anything within +/- 2.00 g of zero as exactly 0 */
    if(weight_centi > -200 && weight_centi < 200)
    {
        weight_centi = 0;
    }

    return (long)weight_centi;
}

/* target_centi is the target weight in centigrams (grams * 100) */
void HX711_MeasureTarget(HX711_CalibrationData *cal, long target_centi)
{
    long current_weight = 0;
    long filtered_raw = 0;
    long last_weight = 0;

    USART2_SendString("\r\n------------------------------------\r\n");
    USART2_SendString(" Target Weight Set To: ");
    USART2_SendWeight(target_centi);
    USART2_SendString(" g\r\n");
    USART2_SendString(" Measuring... (Send CMD 0x00 to Exit)\r\n");
    USART2_SendString("------------------------------------\r\n\r\n");

    while(1)
    {
        /* Check if user sent STOP command (CMD 0x00) */
        if (USART2_CheckForStopCommand()) {
            USART2_SendString(">>> Target Routine Aborted by STOP Command!\r\n");
            break;
        }

        long raw_sample = HX711_ReadAverage(3);

        if(filtered_raw == 0)
        {
            filtered_raw = raw_sample;
        }
        else
        {
            long instant_weight = HX711_GetWeight(cal, raw_sample);
            long diff_instant = instant_weight - last_weight;
            if(diff_instant < 0) diff_instant = -diff_instant;

            /* Threshold scaled to centigrams: 200 centi = 2.00 g,
               same jump-detection sensitivity as before. */
            if(diff_instant > 200)
            {
                filtered_raw = raw_sample;
            }
            else
            {
                filtered_raw = ((filtered_raw * 6) + (raw_sample * 4)) / 10;
            }
        }

        current_weight = HX711_GetWeight(cal, filtered_raw);
        if(current_weight < 0) current_weight = 0;

        if(current_weight >= target_centi)
        {
            USART2_SendString("Current Weight: ");
            USART2_SendWeight(target_centi);
            USART2_SendString(" g\r\n");

            USART2_SendString("\r\n====================================\r\n");
            USART2_SendString(" TARGET REACHED: ");
            USART2_SendWeight(target_centi);
            USART2_SendString(" g\r\n");
            USART2_SendString("====================================\r\n\r\n");

            break;
        }

        USART2_SendString("Current Weight: ");
        USART2_SendWeight(current_weight);
        USART2_SendString(" g [MEASURING...]\r\n");

        last_weight = current_weight;
        HX711_DelayMs(50);
    }
}
