
#ifndef REGISTERS_H
#define REGISTERS_H

#include <stdint.h>

/* ===================== Base addresses ===================== */
#define PERIPH_BASE         0x40000000UL
#define APB1PERIPH_BASE      PERIPH_BASE
#define AHB1PERIPH_BASE     (PERIPH_BASE + 0x00020000UL)

#define RCC_BASE            (AHB1PERIPH_BASE + 0x3800UL)
#define GPIOA_BASE          (AHB1PERIPH_BASE + 0x0000UL)
#define GPIOB_BASE          (AHB1PERIPH_BASE + 0x0400UL)
#define GPIOC_BASE          (AHB1PERIPH_BASE + 0x0800UL)
#define USART2_BASE         (APB1PERIPH_BASE + 0x4400UL)
#define TIM2_BASE           (APB1PERIPH_BASE + 0x0000UL)

/* ===================== RCC ===================== */
#define RCC_AHB1ENR         (*(volatile uint32_t *)(RCC_BASE + 0x30))
#define RCC_APB1ENR         (*(volatile uint32_t *)(RCC_BASE + 0x40))
#define RCC_APB2ENR         (*(volatile uint32_t *)(RCC_BASE + 0x44))

/* ===================== GPIOA ===================== */
#define GPIOA_MODER         (*(volatile uint32_t *)(GPIOA_BASE + 0x00))
#define GPIOA_OTYPER        (*(volatile uint32_t *)(GPIOA_BASE + 0x04))
#define GPIOA_OSPEEDR       (*(volatile uint32_t *)(GPIOA_BASE + 0x08))
#define GPIOA_PUPDR         (*(volatile uint32_t *)(GPIOA_BASE + 0x0C))
#define GPIOA_IDR           (*(volatile uint32_t *)(GPIOA_BASE + 0x10))
#define GPIOA_ODR           (*(volatile uint32_t *)(GPIOA_BASE + 0x14))
#define GPIOA_AFRL          (*(volatile uint32_t *)(GPIOA_BASE + 0x20))
#define GPIOA_AFRH          (*(volatile uint32_t *)(GPIOA_BASE + 0x24))

/* ===================== GPIOB ===================== */
#define GPIOB_MODER         (*(volatile uint32_t *)(GPIOB_BASE + 0x00))
#define GPIOB_OTYPER        (*(volatile uint32_t *)(GPIOB_BASE + 0x04))
#define GPIOB_OSPEEDR       (*(volatile uint32_t *)(GPIOB_BASE + 0x08))
#define GPIOB_PUPDR         (*(volatile uint32_t *)(GPIOB_BASE + 0x0C))
#define GPIOB_IDR           (*(volatile uint32_t *)(GPIOB_BASE + 0x10))
#define GPIOB_ODR           (*(volatile uint32_t *)(GPIOB_BASE + 0x14))

/* ===================== GPIOC ===================== */
#define GPIOC_MODER         (*(volatile uint32_t *)(GPIOC_BASE + 0x00))
#define GPIOC_OTYPER        (*(volatile uint32_t *)(GPIOC_BASE + 0x04))
#define GPIOC_OSPEEDR       (*(volatile uint32_t *)(GPIOC_BASE + 0x08))
#define GPIOC_PUPDR         (*(volatile uint32_t *)(GPIOC_BASE + 0x0C))
#define GPIOC_IDR           (*(volatile uint32_t *)(GPIOC_BASE + 0x10))
#define GPIOC_ODR           (*(volatile uint32_t *)(GPIOC_BASE + 0x14))

/* ===================== USART2 ===================== */
#define USART2_SR           (*(volatile uint32_t *)(USART2_BASE + 0x00))
#define USART2_DR           (*(volatile uint32_t *)(USART2_BASE + 0x04))
#define USART2_BRR          (*(volatile uint32_t *)(USART2_BASE + 0x08))
#define USART2_CR1          (*(volatile uint32_t *)(USART2_BASE + 0x0C))
#define USART2_CR2          (*(volatile uint32_t *)(USART2_BASE + 0x10))
#define USART2_CR3          (*(volatile uint32_t *)(USART2_BASE + 0x14))

/* ===================== TIM2 ===================== */
#define TIM2_CR1            (*(volatile uint32_t *)(TIM2_BASE + 0x00))
#define TIM2_CNT            (*(volatile uint32_t *)(TIM2_BASE + 0x24))
#define TIM2_PSC            (*(volatile uint32_t *)(TIM2_BASE + 0x28))
#define TIM2_ARR            (*(volatile uint32_t *)(TIM2_BASE + 0x2C))

#endif /* REGISTERS_H */
