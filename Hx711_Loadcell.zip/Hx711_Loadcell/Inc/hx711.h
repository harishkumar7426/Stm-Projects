#ifndef HX711_H
#define HX711_H

#include "registers.h"
#include <stdint.h>

#define HX711_DT_PIN    0 /* PC0 */
#define HX711_SCK_PIN   1 /* PC1 */

typedef struct
{
    long tare;               /* raw ADC reading with no load on the scale     */
    long raw_diff;           /* raw ADC delta measured for known_weight_centi */
    long known_weight_centi; /* calibration reference weight, in centigrams   */
                              /* (grams * 100, e.g. 205.50 g -> 20550)         */
} HX711_CalibrationData;

void HX711_Init(void);
long HX711_Read(void);
long HX711_ReadAverage(unsigned char samples);
long HX711_Tare(void);

HX711_CalibrationData HX711_Calibrate(void);

/* Returns weight in centigrams (grams * 100), e.g. 20050 means 200.50 g */
long HX711_GetWeight(HX711_CalibrationData *cal, long raw);

/* target_centi is the target weight in centigrams (grams * 100) */
void HX711_MeasureTarget(HX711_CalibrationData *cal, long target_centi);

#endif /* HX711_H */
