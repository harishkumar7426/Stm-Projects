#ifndef UART_H
#define UART_H

#include "registers.h"
#include <stdint.h>

/* Command Protocol Definitions */
#define CMD_STOP       0x00  /* Emergency Stop / Exit Command */
#define CMD_TARE       0x01  /* Tare Scale Command */
#define CMD_CALIBRATE  0x02  /* Calibration Command */
#define CMD_READ       0x03  /* Single Read Command */
#define CMD_TARGET     0x04  /* Target Measure Command */
#define CMD_MONITOR    0x05  /* Continuous Live Monitoring */

typedef struct {
    uint8_t  start_marker; // 0xAA
    uint16_t id;           // 0x00FF
    uint8_t  command;      // 8-bit command code
    uint32_t data;         // 32-bit uint data payload
    uint8_t  stop_marker;  // 0xFF
    uint8_t  valid;        // 1 if valid, 0 if error
} UART_Packet;

void USART2_TX_Init(void);
void USART2_SendChar(char c);
void USART2_SendString(const char *str);
void USART2_SendNumber(long num);
void USART2_SendHexByte(uint8_t byte);
void USART2_SendHex16(uint16_t val);
char USART2_ReadChar(void);
void USART2_Flush(void);

/* Prints a centigram value (grams * 100) as "XXX.XX" with no trailing
 * unit text (caller appends " g" etc). e.g. 20050 -> "200.50" */
void USART2_SendWeight(long weight_centi);

/* Non-blocking / Safe Input Handlers */
uint8_t USART2_IsDataAvailable(void);
uint8_t USART2_ReadNumber_Safe(int32_t *out_num);

/* Reads an integer or decimal number (e.g. "205", "205.5", "205.55")
 * and returns it as a fixed-point centi-value (value * 100) so the
 * result can be used directly with HX711_GetWeight()/HX711_Calibrate()
 * style centigram math. Extra digits beyond 2 decimal places are
 * echoed but ignored numerically. */
uint8_t USART2_ReadDecimal_Safe(int32_t *out_centi);

UART_Packet USART2_ReceivePacket(void);
uint8_t USART2_CheckForStopCommand(void);

/* Interrupt handler - must match your vector table entry for USART2 */
void USART2_IRQHandler(void);

#endif /* UART_H */
