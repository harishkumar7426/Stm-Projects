Src/main.o: ../Src/main.c ../Inc/uart.h ../Inc/registers.h ../Inc/hx711.h
../Inc/uart.h:
../Inc/registers.h:
../Inc/hx711.h:
