Src/uart.o: ../Src/uart.c ../Inc/uart.h ../Inc/registers.h
../Inc/uart.h:
../Inc/registers.h:
