Src/hx711.o: ../Src/hx711.c ../Inc/hx711.h ../Inc/registers.h \
 ../Inc/uart.h ../Inc/registers.h
../Inc/hx711.h:
../Inc/registers.h:
../Inc/uart.h:
../Inc/registers.h:
