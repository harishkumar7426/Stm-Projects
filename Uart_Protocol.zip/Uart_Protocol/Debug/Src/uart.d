Src/uart.o: ../Src/uart.c ../Inc/registers.h ../Inc/uart.h
../Inc/registers.h:
../Inc/uart.h:
