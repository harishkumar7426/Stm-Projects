Src/gpio.o: ../Src/gpio.c ../Inc/registers.h ../Inc/gpio.h
../Inc/registers.h:
../Inc/gpio.h:
