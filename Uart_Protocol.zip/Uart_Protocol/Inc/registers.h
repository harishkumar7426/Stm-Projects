#ifndef REGISTERS_H
#define REGISTERS_H

#define RCC_BASE       0x40023800
#define GPIOA_BASE     0x40020000
#define USART1_BASE    0x40011000
#define USART2_BASE    0x40004400


// RCC Registers
#define RCC_AHB1ENR   (*(volatile unsigned int *)(RCC_BASE + 0x30))
#define RCC_APB2ENR   (*(volatile unsigned int *)(RCC_BASE + 0x44))
#define RCC_APB1ENR   (*(volatile unsigned int *)(RCC_BASE + 0x40))


// GPIO Registers
#define GPIOA_MODER   (*(volatile unsigned int *)(GPIOA_BASE + 0x00))
#define GPIOA_AFRL    (*(volatile unsigned int *)(GPIOA_BASE + 0x20))
#define GPIOA_AFRH    (*(volatile unsigned int *)(GPIOA_BASE + 0x24))
#define GPIOA_ODR     (*(volatile unsigned int *)(GPIOA_BASE + 0x14))

// GPIOC Registers

#define GPIOC_BASE 0x40020800

#define GPIOC_MODER (*(volatile unsigned int *)(GPIOC_BASE + 0x00))
#define GPIOC_IDR   (*(volatile unsigned int *)(GPIOC_BASE + 0x10))

// USART1 Registers
#define USART1_SR     (*(volatile unsigned int *)(USART1_BASE + 0x00))
#define USART1_DR     (*(volatile unsigned int *)(USART1_BASE + 0x04))
#define USART1_BRR    (*(volatile unsigned int *)(USART1_BASE + 0x08))
#define USART1_CR1    (*(volatile unsigned int *)(USART1_BASE + 0x0C))


// USART2 Registers
#define USART2_SR     (*(volatile unsigned int *)(USART2_BASE + 0x00))
#define USART2_DR     (*(volatile unsigned int *)(USART2_BASE + 0x04))
#define USART2_BRR    (*(volatile unsigned int *)(USART2_BASE + 0x08))
#define USART2_CR1    (*(volatile unsigned int *)(USART2_BASE + 0x0C))


#endif
