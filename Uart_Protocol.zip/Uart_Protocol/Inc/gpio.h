#ifndef GPIO_H
#define GPIO_H


void LED_Init(void);
void Button_Init(void);

void LED_ON(void);
void LED_OFF(void);

int Button_Read(void);


#endif
