#ifndef UART_H
#define UART_H

#include <stdint.h>

void USART1_TX_Init(void);
void USART1_RX_Init(void);
void USART2_TX_Init(void);

void USART1_SendChar(char c);
char USART1_ReceiveChar(void);

void USART2_SendChar(char c);
void USART2_SendString(char *str);

/* Packet functions */
void USART1_SendPacket(uint8_t cmd, uint8_t data);
void USART2_SendHex(uint8_t value);

#endif
