/*
 * gpio.c
 *
 *  Created on: Jul 23, 2026
 *      Author: hkuma
 */


#include "registers.h"
#include "gpio.h"


// PA5 LED initialization

void LED_Init(void)
{

    // Enable GPIOA clock

    RCC_AHB1ENR |= (1<<0);


    // PA5 output mode

    GPIOA_MODER &= ~(3<<10);

    GPIOA_MODER |= (1<<10);

}



// PC13 User Button

void Button_Init(void)
{

    // Enable GPIOC clock

    RCC_AHB1ENR |= (1<<2);


    // PC13 input mode

    GPIOC_MODER &= ~(3<<26);

}



void LED_ON(void)
{

    GPIOA_ODR |= (1<<5);

}



void LED_OFF(void)
{

    GPIOA_ODR &= ~(1<<5);

}



int Button_Read(void)
{

    // Button pressed = 0
    // Button released = 1

    return ((GPIOC_IDR & (1<<13)) == 0);

}
