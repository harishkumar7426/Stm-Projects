#include "registers.h"
#include "uart.h"
#include <stdint.h>

/* Send packet through USART1 */
void USART1_SendPacket(uint8_t cmd, uint8_t data)
{
    USART1_SendChar(0xAA);   // START
    USART1_SendChar(cmd);    // COMMAND
    USART1_SendChar(data);   // DATA
    USART1_SendChar(0x55);   // END
}

/* Print byte as HEX to Tera Term */
void USART2_SendHex(uint8_t value)
{
    char hex[] = "0123456789ABCDEF";

    USART2_SendChar(hex[(value >> 4) & 0x0F]);
    USART2_SendChar(hex[value & 0x0F]);
    USART2_SendChar(' ');
}

// USART1 PA9 TX
void USART1_TX_Init(void)
{

    // Enable GPIOA clock
    RCC_AHB1ENR |= (1<<0);


    // Enable USART1 clock
    RCC_APB2ENR |= (1<<4);


    // PA9 Alternate Function
    GPIOA_MODER &= ~(3<<18);
    GPIOA_MODER |= (2<<18);


    // AF7 for PA9
    GPIOA_AFRH &= ~(0xF<<4);
    GPIOA_AFRH |= (7<<4);


    // Baud 9600 @16MHz
    USART1_BRR = 0x0683;


    // Enable TX and USART
    USART1_CR1 |= (1<<3);
    USART1_CR1 |= (1<<13);

}



// USART1 PA10 RX
void USART1_RX_Init(void)
{

    RCC_AHB1ENR |= (1<<0);

    RCC_APB2ENR |= (1<<4);


    // PA10 Alternate Function
    GPIOA_MODER &= ~(3<<20);
    GPIOA_MODER |= (2<<20);


    // AF7
    GPIOA_AFRH &= ~(0xF<<8);
    GPIOA_AFRH |= (7<<8);



    USART1_BRR = 0x0683;


    // Enable RX
    USART1_CR1 |= (1<<2);

    // Enable USART
    USART1_CR1 |= (1<<13);

}



// USART2 PA2 TX for Tera Term

void USART2_TX_Init(void)
{

    RCC_AHB1ENR |= (1<<0);

    RCC_APB1ENR |= (1<<17);


    // PA2 AF mode
    GPIOA_MODER &= ~(3<<4);
    GPIOA_MODER |= (2<<4);


    // AF7
    GPIOA_AFRL &= ~(0xF<<8);
    GPIOA_AFRL |= (7<<8);


    USART2_BRR = 0x0683;


    USART2_CR1 |= (1<<3);
    USART2_CR1 |= (1<<13);

}



void USART1_SendChar(char c)
{

    while(!(USART1_SR & (1<<7)));

    USART1_DR=c;

}



char USART1_ReceiveChar(void)
{

    while(!(USART1_SR & (1<<5)));

    return USART1_DR;

}



void USART2_SendChar(char c)
{

    while(!(USART2_SR & (1<<7)));

    USART2_DR=c;

}



void USART2_SendString(char *str)
{

    while(*str)
    {
        USART2_SendChar(*str++);
    }

}
