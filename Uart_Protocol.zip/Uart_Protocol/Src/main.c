// UART PACKET TRANSFORMATION
/*receiver*/
#include "uart.h"
#include "gpio.h"
#include <stdint.h>

#define START_BYTE  0xAA
#define END_BYTE    0x55

int main(void)
{
    USART1_RX_Init();   // Receive from TX board
    USART2_TX_Init();   // Print to Tera Term
    LED_Init();

    uint8_t start, cmd, data, end;

    while(1)
    {
        /* Wait for START byte */
        start = USART1_ReceiveChar();

        if(start == START_BYTE)
        {
            /* Receive remaining bytes */
            cmd  = USART1_ReceiveChar();
            data = USART1_ReceiveChar();
            end  = USART1_ReceiveChar();

            /* Validate END byte */
            if(end == END_BYTE)
            {
                /* Print packet in HEX */
                USART2_SendString("RX Packet: ");
                USART2_SendHex(start);
                USART2_SendHex(cmd);
                USART2_SendHex(data);
                USART2_SendHex(end);
                USART2_SendString("\r\n");

                /* Execute command */
                if(cmd == 0x01)
                {
                    if(data == 0x01)
                    {
                        LED_ON();
                    }
                    else if(data == 0x00)
                    {
                        LED_OFF();
                    }
                }
            }
            else
            {
                USART2_SendString("Invalid Packet\r\n");
            }
        }
    }
}
/*
 //Transmitter
#include "uart.h"
#include "gpio.h"
#include <stdint.h>
int main(void)
{
    USART1_TX_Init();
    Button_Init();

    uint8_t previous = 0xFF;

    while(1)
    {
        uint8_t current = Button_Read();

        //Send only when state changes
        if(current != previous)
        {
            if(current)
            {
                // Button pressed -> LED ON packet
                USART1_SendPacket(0x01, 0x01);
            }
            else
            {
                // Button released -> LED OFF packet
                USART1_SendPacket(0x01, 0x00);
            }

            previous = current;
        }
    }
}
*/
